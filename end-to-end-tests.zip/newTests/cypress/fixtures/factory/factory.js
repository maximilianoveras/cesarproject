
import BaseFactory from "./_base"



export default class Factory extends BaseFactory {
   static merchant() {
        const legal_document_number = `${BaseFactory.makeLegalDocument()}`;
        const BUC = String(Date.now()).substring(5, 13)
        let merchant = {
            "country": "MX",
            "external_merchant_id": BUC,
            "legal_document_number": legal_document_number,
            "name": `Merchant ${BUC}`
        };
        return merchant

    }

    static legalRepresentative() {

        const BUC = String(Date.now()).substring(5, 13)
        let legal_document_number = `${BaseFactory.generateValidRFC()}`
        let email = `${legal_document_number}@usweek.net`.toLowerCase();

        let legalRepresentative = {
            "contacts": [{
                "contact_id": BaseFactory.chance().guid({ version: 4 }),
                "external_contact_id": BUC,
                "identifier_document_number": "passport",
                "legal_document_number": legal_document_number,
                "name": "Jose",
                "surname": "Alvaquez",
                "birth_date": "1981-12-10",
                "phone": {
                    "country_code": "52",
                    "area_code": "55",
                    "number": BaseFactory.chance().string({ length: "8", numeric: true })
                },
                "cell_phone": {
                    "country_code": "52",
                    "area_code": "55",
                    "number": BaseFactory.chance().string({ length: "8", numeric: true })
                },
                "email": email,
                "role": "legal_representative",
                "address": {
                    "street": "Calle Parque Lira",
                    "number": "SN",
                    "suite": "1",
                    "district": "Bosque de Chapultepec I Sección",
                    "city": "Miguel Hidalgo",
                    "state": "TAMPICO",
                    "country": "MX",
                    "postal_code": "11850"
                },
                "address_reference_point": "string"
            }],
            "fiscal_address": {
                "street": "Calle Parque Lira",
                "number": "SN",
                "suite": "1",
                "district": "Bosque de Chapultepec I Sección",
                "city": "Miguel Hidalgo",
                "state": "TAMPICO",
                "country": "MX",
                "postal_code": "11850"
            },
            "fiscal_address_reference_point1": "Farmacia merchant",
            "fiscal_address_reference_point2": "Restaurante merchant",
            "phone": {
                "country_code": "52",
                "area_code": "55",
                "number": BaseFactory.chance().string({ length: "8", numeric: true })
            },
            "commercial_information": {
                "currency": "MXN",
                "gross_monthly_income": 200000,
                "gross_monthly_digital_payments": 200000,
                "average_ticket": 1000
            },
            "days_to_delivery": 0,
            "installments_without_interest": false
        }

        return legalRepresentative
    };

    static merchantAccount() {
        let merchantAccount = {
            "name": "test",
            "account_type": "simple",
            "tags": [
                "string"
            ],
            "bank_account": {
                "bank_code": "014",
                "bank_country": "MX",
                "currency": "MXN",
                "account_number": `014${BaseFactory.chance().string({ length: 15, numeric: true })}`,
                "branch_code": "BAD336"
            },
            "merchant_id": ''
        }
        return merchantAccount;

    }

    static seller() {
        return {
            totalMonthlyBilling: super.randomInteger(6), /** De acordo com esse faturamento serão apresentado certos produtos */
            totalBillingWithCards: super.randomInteger(5),
            averageVoucher: super.randomInteger(4),
            category: "restaurantes"
        }
    }
}
