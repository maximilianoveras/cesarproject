const { MongoClient } = require("mongodb")
const uri = "mongodb+srv://sample-hostname:27017/?poolSize=20&writeConcern=majority"
const client = new MongoClient(uri)
const Chance = require('chance');
const chance = new Chance();

export default class BaseFactory {
  static chance() {
    return chance
  }

  static makeString(length = 18, onlyNumbers = false) {
    let result = '';
    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let numbers = '0123456789';
    for (let i = 0; i < length; i++) {
      if (onlyNumbers) result += numbers.charAt(~~(Math.random() * numbers.length));
      else result += characters.charAt(~~(Math.random() * characters.length));
    }
    return result.toUpperCase();
  }

  static  makeLegalDocument() {
    const numbers = '0123456789';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let threeOrFour = ~~(Math.random() * (5 - 3)) + 3;
    threeOrFour = 4;
    let res = '';
    for (let i = 0; i < (threeOrFour + 9); i++) {
      if (i < threeOrFour) res += chars.charAt(~~(Math.random() * chars.length));
      else if (i < (threeOrFour + 6)) res += numbers.charAt(~~(Math.random() * numbers.length));
      else res += `${chars}${numbers}`.charAt(~~(Math.random() * `${chars}${numbers}`.length));
    }
    return res;
  }

  static randomDate(start, end) {
    const date = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
    let result = `${date.getFullYear().toString().substr(-2)}${date.getMonth(date)}${date.getDay(date)}`;
    return result.toUpperCase();
  }

  static generateValidRFC(year = 1960) {
    return `${this.makeString(~~(Math.random() * (5 - 3)) + 3)}${this.randomDate(new Date(year, 0, 1), new Date(2001, 0, 1))}${this.makeString(3)}`;
  }

  
  static randomInteger(digits) {
    if (digits === 1) {
      return Math.floor(Math.random() * 9) + 1
    } else {
      let aux = '1'
      for (let i = 1; i < digits; i++)
        aux += '0'
      return Math.floor(Math.random() * 9) + parseInt(aux)
    }
  }

  static async getDataFromDatabase() {
    // mongo example
    try {
      await client.connect()
      await client.db("db").command({ ping: 1 })
      console.log("Connected successfully to server")
      // substituir o ping pelo get no mongo
    } catch (err) {
      cy.log('MONGO ERROR: ' + err)
    } finally {
      await client.close()
    }
  }

  static async setDataInDatabase(data) {
    // mongo example
    try {
      await client.connect()
      await client.db("db").command({ ping: 1 })
      console.log("Connected successfully to server")
      // substituir o ping pelo set no mongo
    } catch (err) {
      cy.log('MONGO ERROR: ' + err)
    } finally {
      await client.close()
    }
  }
}
