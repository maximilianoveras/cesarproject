import Base from "./_base.page"

// elementos
const exampleElement = '[href="/login"]';

export default class Home extends Base {
  static exampleMethod(title) {
    super.verifyIfElementExists(exampleElement);
    cy.contains(title);
  }
}
