import Base from "./_base.page"
import * as Support from "../../support/index"

// elements
const inputUser = '[href="/login"]'
const inputPassword = '#password'
const inputOneTimePassword = '#oneTimePass'

// fixtures
const onboarding2 = `onboarding2${Cypress.env('environment')}`

export default class Onboarding2 extends Base {
  static login() {
    cy.fixture(onboarding2).as('dataLoader').then((dataLoader) => {
      //super.typeValue(inputUser, dataLoader.user)
      //super.typeValue(inputPassword, dataLoader.password)
      Support.throwImplementationError()
    })
  }

  static setOneTimePassword() {
    cy.fixture(onboarding2).as('dataLoader').then((dataLoader) => {
      // go to email dataLoader.email and get password
      // save to const oneTimePassword
      //super.typeValue(inputOneTimePassword, oneTimePassword)
      Support.throwImplementationError()
    })
  }

  static checkMessage(message){
    super.getElementContaining(message)
  }
}
