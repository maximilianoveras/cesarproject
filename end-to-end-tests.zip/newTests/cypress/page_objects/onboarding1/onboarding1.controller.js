import Account from "./account.page";
import Home from "./home.page";
import Login from "./login.page"
import Product from "./products.page";
import SelectAffiliation from "./select_affiliation.page";

export default class Onboarding1Controller  {

  constructor() {
        this.login = new Login();
        this.home  = new Home();
        this.account = new Account();
        this.selectAffiliation = new SelectAffiliation();
        this.product = new Product();
  }
  
}