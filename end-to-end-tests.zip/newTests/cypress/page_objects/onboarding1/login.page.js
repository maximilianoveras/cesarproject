import Base from "../_base.page"

// Mapping RFC button
const RFCbutton = `//span[contains(text(), 'RFC')]`;
const RFCinput = `//input[@name='client_number']`;

export default class Login extends Base {
 loginRFC(RFC) {
    super.verifyIfElementExists(RFCbutton);
    super.clickOnElement(RFCbutton);
    super.verifyIfElementExists(RFCinput);
    super.typeValueXPath(RFCinput,RFC,true);
    cy.screenshot("1_login_by_rfc");
    this.continue();
  }
}
