import Base from "../_base.page"

const RFCproofDocument = `//a[text() = 'Adjuntar']`;
const passportProofDocument = `//a[text() = 'Adjuntar']`;
const documentTypeCombo = `//div[text()="Tipo de documento"]/preceding-sibling::input`;
const RFCproofOption = `//div[text()="Comprobante del RFC"]`;
const passportProofOption = `//div[text()="pasaporte"]`;
const merchantCard = `//p[text()='Comercio']`;
const merchantLegalCard = `//p[text()='Representante legal']`;

export default class Home extends Base {
    async addDocuments() {
        this.pageLoaded();
        super.clickOnElement(RFCproofDocument, 0);
        super.clickOnElement(documentTypeCombo);
        super.verifyIfElementExists(RFCproofOption);
        super.clickOnElement(RFCproofOption);
        await this.uploadFile("RFCproofDocument.jpg", "image/jpg", "RFCproofDocument");

        super.clickOnElement(passportProofDocument, 1);
        super.clickOnElement(documentTypeCombo);
        super.verifyIfElementExists(passportProofOption);
        super.clickOnElement(passportProofOption);
        await this.uploadFile("passportProofDocument.jpg", "image/jpg", "passportProofDocument");
        cy.screenshot("2_add_documents");        
    }

    verifyFilesIsPending() {
        this.pageLoaded();
        cy.contains(`Adjuntar`).should('have.length', 1);
    }

    pageLoaded() {
        this.verifyIfElementExists(merchantCard);
        this.verifyIfElementExists(merchantLegalCard);
    }
}
