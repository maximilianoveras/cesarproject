import Base from "../_base.page"

const accountButton = `//div[@name='shop']`;

export default class Account extends Base {
    selectAccount(orderNumber = 0) {
        orderNumber = orderNumber == 0 ? orderNumber: orderNumber -1
        super.verifyIfElementExists(accountButton);
        super.clickOnElement(accountButton, orderNumber);
    }

    pageLoaded() {
        super.verifyIfElementExists(`//span[text()='CLABE']`);
        cy.screenshot("3_accounts");
    }
}
