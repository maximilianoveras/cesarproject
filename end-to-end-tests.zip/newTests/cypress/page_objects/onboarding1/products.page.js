import Base from "../_base.page"

const feeTittle = `//h2[text()='Tasas Mínimas']`;
const addProductMessage = `//p[text()='AÑADIR AL CARRITO']`;

const productInformationsMap = {
    credit_mdr: {
        xpath: `//input[@name='credit']`,
        element_type: "input"
    },
    debit_mdr: {
        xpath: `//input[@name='debit']`,
        element_type: "input"
    },
    international_mdr: {
        xpath: `//input[@name='credit_international']`,
        element_type: "input"
    },
    gsmart_quantity: {
        xpath: `//h2[text() = 'GSmart']/../../../..//p[contains(text(), 'AÑADIR AL CARRITO')]`,
        element_type: "button",
        wait: 1000
    },
    cellphone_tip_quantity: {
        xpath: `//h2[text() = 'TPV Celular con Propina']/../../../..//p[contains(text(), 'AÑADIR AL CARRITO')]`,
        element_type: "button",
        wait: 1000
    },
    ethernet_tip_quantity: {
        xpath: `//h2[text() = 'TPV Fija con Propina']/../../../..//p[contains(text(), 'AÑADIR AL CARRITO')]`,
        element_type: "button",
        wait: 1000
    },
    wifi_tip_quantity: {
        xpath: `//h2[text() = 'TPV Wifi con Propina']/../../../..//p[contains(text(), 'AÑADIR AL CARRITO')]`,
        element_type: "button",
        wait: 1000
    }
}

export default class Product extends Base {

    pageLoaded() {
        super.verifyIfElementExists(feeTittle);
    }

    productsLoaded() {
        super.verifyIfElementExists(addProductMessage);
    }

    async addProductInformation(fieldName, fieldContent = "default") {
        await super.setInfo(productInformationsMap, fieldName, fieldContent);
    }
}
