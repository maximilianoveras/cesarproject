import Base from "../_base.page"

const newAffiliationOption = `//div[text()='Nueva Afiliación']/preceding-sibling::div`;
const updateAquirer = `//div[text()='Cambio de Adquirencia']/preceding-sibling::div`;

const sellerInformationsMap = {
    total_billing: {
        xpath: `//input[@name='legal.commercial_information.gross_monthly_income']`,
        element_type: "input"
    },
    total_card_billing: {
        xpath: `//input[@name='legal.commercial_information.gross_monthly_digital_payments']`,
        element_type: "input"
    },
    average_ticket: {
        xpath: `//input[@name='legal.commercial_information.average_ticket']`,
        element_type: "input"
    },
    family: {
        xpath: `//label[@label='Família']`,
        element_type: "combobox"
    },
    MCC: {
        xpath: `//label[@label='GIRO']`,
        element_type: "combobox",
        wait: 1000
    },
};

export default class SelectAffiliation extends Base {

    pageLoaded() {
        super.verifyIfElementExists(newAffiliationOption);
        super.verifyIfElementExists(updateAquirer);
        cy.screenshot("4_select_affiliation_page");
    }

    addSellerInformation(fieldName, fieldContent) {
        super.setInfo(sellerInformationsMap, fieldName, fieldContent);
    }
}
