import path from "path"

const saveButton = `//span[contains(text(), 'Guardar')]`;
const fileSavedMessage = `//p[text()="Archivo enviado!"]`;
const closeButton = `//span[text()="Cerrar"]`;
const fileInput = `input[type=file]`;
const continueButton = `//span[contains(text(), 'Continuar')]`;
const confirmButton = `//span[contains(text(), 'Confirmar')]`;

export default class Base {
  getElement(element, index = undefined) {
    let elem;

    if (typeof index !== 'undefined' || index > 0) {
      elem = cy.get(element, { timeout: Cypress.env('global_timeout') }).eq(index);
    } else {
      elem = cy.get(element, { timeout: Cypress.env('global_timeout') });
    }
    return elem;
  }

  getElementByXpath(element, index = undefined) {
    let elem;

    if (typeof index !== 'undefined' || index > 0) {
      elem = cy.xpath(element, { timeout: Cypress.env('global_timeout') }).eq(index);
    } else {
      elem = cy.xpath(element, { timeout: Cypress.env('global_timeout') });
    }
    return elem;
  }


  getElementContaining(text) {
    return cy.contains(text, { timeout: Cypress.env('global_timeout') }).should('be.visible');
  }

  getElementByXPath(element, index) {
    let elem;

    if (typeof index !== 'undefined' || index > 0) {
      elem = cy.xpath(element, { timeout: Cypress.env('global_timeout') }).eq(index);
    } else {
      elem = cy.xpath(element, { timeout: Cypress.env('global_timeout') });
    }

    return elem;
  }

  validateText(baseValue, comparingValue) {
    expect(baseValue).to.contains(comparingValue);
  }

  validateElementText(element, value, index = undefined) {
    this.getElementText(element, index).then((text) => {
      expect(text).to.contains(value);
    });
  }

  getElementText(element, index = undefined) {
    return this.getElement(element, index).invoke('text');
  }

  typeValue(element, value, force = false) {
    if (force === true) {
      this.getElement(element).type(value, { force: true });
    } else {
      this.getElement(element).type(value);
    }
  }

  typeValueXPath(element, value, force = false) {
    if (force === true) {
      this.getElementByXPath(element).clear({ force: true }).type(value, { force: true });
    } else {
      this.getElementByXPath(element).clear({ force: true }).type(value);
    }
  }

  typeWithDay(element, value) {
    this.getElement(element).type(value, { timeout: Cypress.env('global_timeout') });
  }

  async clickOnElement(element, index = undefined, force = false) {
    if (force === true) {
      return this.getElementByXpath(element, index).click({ force: true });
    } else {
      return this.getElementByXpath(element, index).click();
    }
  }

  async verifyIfElementExists(xpath, css = null) {
    if (xpath) {
      this.getElementByXpath(xpath).should('exist', { timeout: Cypress.env('global_timeout') });
    } else {
      this.getElement(css).should('exist', { timeout: Cypress.env('global_timeout') });
    }

  }

  verifyIfElementIsHidden(element) {
    this.getElement(element).should('not.be.visible', { timeout: Cypress.env('global_timeout') });
  }

  selectOption(element, option) {
    return this.getElement(element).select(option);
  }

  uploadFile(documentPath, documentExtension, documentName) {
    documentPath = path.join("documents", documentPath);

    cy.fixture(documentPath).as(documentName)
    cy.get(fileInput).then(function (el) {
      const blob = Cypress.Blob.base64StringToBlob(this[documentName], documentExtension)

      const file = new File([blob], documentPath, { type: documentExtension })
      const list = new DataTransfer()

      list.items.add(file)
      const myFileList = list.files

      el[0].files = myFileList
      el[0].dispatchEvent(new Event('change', { bubbles: true }));

    });

    this.clickOnElement(saveButton);
    this.verifyIfElementExists(fileSavedMessage);
    this.clickOnElement(closeButton);
  }

  async setInfo(fieldsMap, fieldName, fieldContent) {
    if (fieldContent != "default") {

      const field = fieldsMap[fieldName];

      if (field.wait) {
        cy.wait(field.wait);
      }

      switch (field.element_type) {
        case "input":
          this.typeValueXPath(field.xpath, fieldContent, true);
          break;

        case "combobox":
          this.verifyIfElementExists(field.xpath);
          this.clickOnElement(field.xpath);
          const optionToSelect = `//div[text()='${fieldContent}']`;
          this.verifyIfElementExists(optionToSelect);
          this.clickOnElement(optionToSelect);
          break;

        case "button":
          this.verifyIfElementExists(field.xpath);
          await this.clickOnElement(field.xpath);
          break;

        default:
          this.typeValueXPath(field.xpath, fieldContent);
          break;
      }
    }
  }

  continue() {
    cy.screenshot();
    this.clickOnElement(continueButton);
  }

  confirm() {
    cy.screenshot();
    this.clickOnElement(confirmButton);
  }
}
