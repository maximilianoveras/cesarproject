beforeEach(() => {
  cy.log(
    "This will run once before all scenarios"
  )
  // cy.visit('') //This function will make all the scenarios begin in the BaseUrl(config/prod.json)
  // cy.clearLocalStorage()
  // cy.reload()
})
