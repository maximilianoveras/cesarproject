import request from "request"


export default class BackendIntegration {

    saveInStorage(name, data) {
        sessionStorage.setItem(name, JSON.stringify(data));
    }

    getFromStorage(name, isObject = true) {
        let data = sessionStorage.getItem(name);

        if (isObject) {
            data = JSON.parse(data);
        }

        return data;
    }

    async doRequest(req) {
        return new Promise((resolve, reject) => {
            request(req, (error, response, body) => {
                if (error) {
                    resolve(null);
                }
                else {
                    resolve(JSON.parse(body))
                }
            })
        })
    }

    async getHeader() {
        let access_token = await this.getAuthCode()
        const headers = {
            "content-type": "application/json",
            'X-Subscription-Key': 'a94ae7388155422889577ab4d630e7f8',
            'Authorization': `Bearer ${access_token}`,
        }
        return headers;
    }

    async getAuthCode() {
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        const queryParams = {
            grant_type: 'client_credentials',
            client_id: 'qa-token',
            client_secret: 'qa-secret',
            scope: 'token'
        }
        const req = {
            method: 'POST',
            uri: 'https://api.pre.globalgetnet.com/oauth2/uat-core/access_token',
            headers: headers,
            form: queryParams
        };

        let response = await this.doRequest(req);
        return response.access_token;
    }

    async createMerchant() {
        const headers = await this.getHeader()
        let merchant = this.getFromStorage("merchant")
        let req = {
            method: "POST",
            uri: "https://api.pre.globalgetnet.com/onboarding/v1/merchants",
            body: JSON.stringify(merchant),
            headers: headers
        }
        merchant = await this.doRequest(req);

        expect(merchant.merchant_id).not.to.be.equal(null || undefined || '')
        this.saveInStorage("merchant", merchant);

    };

    async createMerchantLegal() {
        const headers = await this.getHeader()
        const merchant = this.getFromStorage("merchant");
        let merchantLegal = this.getFromStorage("merchantLegal");

        let req = {
            method: "POST",
            uri: `https://api.pre.globalgetnet.com/onboarding/v1/merchants/${merchant.merchant_id}/mx-legals`,
            body: JSON.stringify(merchantLegal),
            headers: headers
        }
        merchantLegal = await this.doRequest(req);

        expect(merchantLegal.merchant_id).not.to.be.equal(null || undefined || '')
        this.saveInStorage("merchantLegal", merchantLegal);

    };

    async createMerchantAccount() {
        const headers = await this.getHeader()
        const merchant = this.getFromStorage("merchant");
        let merchantAccount = this.getFromStorage("merchantAccount");
        merchantAccount.merchant_id = merchant.merchant_id;

        let req = {
            method: "POST",
            uri: "https://api.pre.globalgetnet.com/onboarding/accounts/v1/merchant-accounts",
            body: JSON.stringify(merchantAccount),
            headers: headers
        }

        merchantAccount = await this.doRequest(req);
        expect(merchantAccount.merchant_account_id).not.to.be.equal(null || undefined || '')
        this.saveInStorage("merchantAccount", merchantAccount);

    };

}