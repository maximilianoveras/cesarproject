import { Given, When, Then, then } from "cypress-cucumber-preprocessor/steps"
import * as Support from "../../support/index"
import Factory from "../../fixtures/factory/factory"
import Onboarding1Controller from "../../page_objects/onboarding1/onboarding1.controller"
import BackendIntegration from "./common/backendIntegration"

const backendIntegration = new BackendIntegration()
const Onboarding1 = new Onboarding1Controller()

Given(`that is on the onboarding 1.0 page`, () => {
  cy.visit('https://branch.pre.globalgetnet.com/?code=Q09ERV9PTkJPQVJESU5H')
})

Given(`has the merchant data`, () => {
  const merchant = Factory.merchant();
  backendIntegration.saveInStorage("merchant", merchant);
})

Given(`has the legal representative data`, () => {
  const merchantLegal = Factory.legalRepresentative();
  backendIntegration.saveInStorage("merchantLegal", merchantLegal);
})

Given(`has the merchant account data`, () => {
  const merchantAccount = Factory.merchantAccount();
  backendIntegration.saveInStorage("merchantAccount", merchantAccount);
})

When(`login in the onboarding 1.0`, async () => {
  const merchant = await backendIntegration.getFromStorage("merchant");
  cy.log(merchant);
  await Onboarding1.login.loginRFC(merchant.legal_document_number);

})


Given(`has the merchant, legal representative and merchant account registered`,
  async () => {
    await backendIntegration.createMerchant();
    await backendIntegration.createMerchantLegal();
    await backendIntegration.createMerchantAccount();
  });

Then(`merchant and his legal data should be shown`, async () => {
  await Onboarding1.home.pageLoaded();
});

Given(`that merchant documents upload is pending`, async () => {
  await Onboarding1.home.verifyFilesIsPending();
});

When(`the files are uploaded`, async () => {
  await Onboarding1.home.addDocuments();
});

Then(`it should be possible to continue to the next page`, async () => {
  await Onboarding1.home.continue();
});

Given(`that it is on account page`, async () => {
  Onboarding1.account.pageLoaded();
});

When(`the {int} account is selected`, async (accountOrderNumber) => {
  Onboarding1.account.selectAccount(accountOrderNumber);
});

Then(`new affiliation option should be shown`, async () => {
  Onboarding1.selectAffiliation.pageLoaded();
});

Given(`that new affiliation option is visible`, async () => {
  Onboarding1.selectAffiliation.pageLoaded();
});


Given(`there is a seller to be registered`, () => {
  const seller = Factory.seller();
  backendIntegration.saveInStorage("seller", seller);
})

Given(`this seller {string} is {string}`, async (fildName, fildContent) => {
  Onboarding1.selectAffiliation.addSellerInformation(fildName, fildContent);
});

When(`save this informations`, () => {
  Onboarding1.selectAffiliation.continue();
});

Then(`the products page should be shown`, () => {
  Onboarding1.product.pageLoaded();
});

Given(`it is in the MDR configuration page`, () => {
  Onboarding1.product.pageLoaded();
});

Given(`the {string} product information is {string}`, async (fildName, fildContent) => {
  Onboarding1.product.addProductInformation(fildName, fildContent);
});


When(`the MDR configuration is confirmed`, () => {
  Onboarding1.product.confirm();
});

Then(`avaliable products should be shown`, () => {
  Onboarding1.product.productsLoaded();
});

Given(`it is in the product select page`, () => {
  Onboarding1.product.productsLoaded();
});

Given(`it is selected {string} products {string}`, async (quantity, productName) => {
  // let addedProducts = 0;

  // // while(addedProducts != quantity) {
  //   cy.log(productName);
  //   await Onboarding1.product.addProductInformation(productName);
   
  //   await Onboarding1.product.getElementByXPath(`//p[text()='${productName}']`).then(
  //     async text => {
  //       cy.log(text);
  //       // addedProducts = parseInt(text);
  //     }
  //   );
  // // }
  
});


When(`the products selection is confirmed`, () => {
  Onboarding1.product.continue();
});

Then(`the contacts page should be shown`, () => {

});