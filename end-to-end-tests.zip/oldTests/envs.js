const token = {
    uat: {
        SUBSCRIPTION_KEY: '67fc8f726f264e5ca0c54830d023e2ed',
        TOKEN: {
            URL: "https://api.pre.globalgetnet.com/oauth2/uat-core/access_token",
            QUERY: {
                'grant_type': 'client_credentials',
                'client_id': 'payments-id',
                'client_secret': 'payments-secret',
                'scope': 'token'
            }
        }
    },
    qa: {
        SUBSCRIPTION_KEY: 'f726e5ff42244898b983ac3689e88b90',
        TOKEN: {
            URL: "https://api.api-gateway.dev.gms.corp/dev/sanmx/authentication/oauth2/dev-core/access_token",
            QUERY: {
                'grant_type': 'client_credentials',
                'client_id': 'postman-payments-id',
                'client_secret': 'postman-payments-secret',
                'scope': 'credit-ms'
            }
        }
    },
    dev: {
        SUBSCRIPTION_KEY: 'f726e5ff42244898b983ac3689e88b90',
        TOKEN: {
            URL: "https://api.api-gateway.dev.gms.corp/dev/sanmx/authentication/oauth2/dev-core/access_token",
            QUERY: {
                'grant_type': 'client_credentials',
                'client_id': 'qa-token',
                'client_secret': 'qa-secret',
                'scope': 'token'
            }
        }
    }
}

const urls = (paymentParams) => {
    let url = {
        uat: {
            AUTHORIZATION: "https://api.pre.globalgetnet.com/payments/v1/authorization",
            PRE_AUTHORIZATION: "https://api.pre.globalgetnet.com/payments/v1/pre-authorization",
            REVERSAL: `https://api.pre.globalgetnet.com/payments/v1/${paymentParams.payment_id}/reversal`,
            REFUND: `https://api.pre.globalgetnet.com/payments/v1/${paymentParams.payment_id}/refund`,
            CANCELLATION: `https://api.pre.globalgetnet.com/payments/v1/${paymentParams.payment_id}/cancellation`,
            CAPTURE: `https://api.pre.globalgetnet.com/payments/v1/${paymentParams.payment_id}/capture`
        },
        qa: {
            AUTHORIZATION: "https://api.api-gateway.dev.gms.corp/qa/sanmx/payments/v1/authorization",
            PRE_AUTHORIZATION: "https://api.api-gateway.dev.gms.corp/qa/sanmx/payments/v1/pre-authorization",
            REVERSAL: `https://api.api-gateway.dev.gms.corp/qa/sanmx/payments/v1/${paymentParams.payment_id}/reversal`,
            REFUND: `https://api.api-gateway.dev.gms.corp/qa/sanmx/payments/v1/${paymentParams.payment_id}/refund`,
            CANCELLATION: `https://api.api-gateway.dev.gms.corp/qa/sanmx/payments/v1/${paymentParams.payment_id}/cancellation`,
            CAPTURE: `https://api.api-gateway.dev.gms.corp/qa/sanmx/payments/v1/${paymentParams.payment_id}/capture`
        },
        dev: {
            AUTHORIZATION: "https://api.api-gateway.dev.gms.corp/dev/sanmx/payments/v1/authorization",
            PRE_AUTHORIZATION: "https://api.api-gateway.dev.gms.corp/dev/sanmx/payments/v1/pre-authorization",
            REVERSAL: `https://api.api-gateway.dev.gms.corp/dev/sanmx/payments/v1/${paymentParams.payment_id}/reversal`,
            REFUND: `https://api.api-gateway.dev.gms.corp/dev/sanmx/payments/v1/${paymentParams.payment_id}/refund`,
            CANCELLATION: `https://api.api-gateway.dev.gms.corp/dev/sanmx/payments/v1/${paymentParams.payment_id}/cancellation`,
            CAPTURE: `https://api.api-gateway.dev.gms.corp/dev/sanmx/payments/v1/${paymentParams.payment_id}/capture`
        }
    }
    return (url)
}

module.exports = {
    urls,
    token
};