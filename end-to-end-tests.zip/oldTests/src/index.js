(async () => {
    const dependencies = require('./dependencies');
    const application = dependencies.resolve('application');
    await application.start();
})(); 