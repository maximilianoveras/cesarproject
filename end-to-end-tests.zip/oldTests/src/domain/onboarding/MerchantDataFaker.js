const faker = require('faker/locale/es_MX');

const Utils = require('support/Utils');

class DatafakerMerchant {

  _generateContacts(count = 1) {
    let contacts = [];

    for (let i = 0; i < count; i++) {

      const contact = {
        "external_contact_id": Utils.generateExternalContactId(),
        "legal_document_number": Utils.generateValidRFC(),
        "identifier_document_number": "INE",
        "name": faker.name.firstName(),
        "surname": faker.name.lastName(),
        "birth_date": Utils.generateDateISO(new Date(1940, 0, 1), new Date(2001, 0, 1)),
        "phone": {
          "country_code": "52",
          "area_code": "55",
          "number": `${Utils.makeString(8, true)}`
        },
        "cell_phone": {
          "country_code": "52",
          "area_code": "55",
          "number": `${Utils.makeString(8, true)}`
        },
        "email": faker.internet.email().toLowerCase(),
        "role": "legal_representative",
        "address": {
          "street": faker.address.streetName(),
          "number": `${Utils.makeString(3, true)}`,
          "suite": `${Utils.makeString(1, true)}`,
          "district": `${faker.address.state()} ${faker.address.stateAbbr()}`,
          "city": faker.address.city(),
          "state": faker.address.state(),
          "country": "MX",
          "postal_code": "11850"
        },
        "address_reference_point": faker.lorem.words(2)
      };

      contacts.push(contact);
    }

    return contacts;
  };

  generateMerchant(acquirer_merchant_category_code, merchant_category_code) {

    return {
      "country": "MX",
      "external_merchant_id": Utils.generateExternalContactId(),
      "legal_document_number": Utils.generateValidRFC(),
      "name": `${faker.company.companyName()} ${faker.company.companySuffix()} - E2E`,
      "economic_activity_profile": {
        acquirer_merchant_category_code,
        merchant_category_code
      }
    };

  };

  generateMerchantLegal() {

    return {
      "contacts": this._generateContacts(),
      "fiscal_address": {
        "street": faker.address.streetName(),
        "number": `${Utils.makeString(3, true)}`,
        "suite": `${Utils.makeString(1, true)}`,
        "district": `${faker.address.state()} ${faker.address.stateAbbr()}`,
        "city": faker.address.city(),
        "state": faker.address.state(),
        "country": "MX",
        "postal_code": "11850"
      },
      "fiscal_address_reference_point1": faker.lorem.words(2),
      "fiscal_address_reference_point2": faker.lorem.words(2),
      "phone": {
        "country_code": "52",
        "area_code": "33",
        "number": `${Utils.makeString(8, true)}`
      },
      "commercial_information": {
        "currency": "MXN",
        "gross_monthly_income": 74999,
        "gross_monthly_digital_payments": 74999,
        "average_ticket": 100
      },
      "days_to_delivery": 0,
      "installments_without_interest": false
    };

  };

  generateMerchantAccount(merchant_id) {
    const dataAccounts = {
      "account_type": "simple",
      merchant_id,
      "bank_account": {
        "account_number": `${Utils.makeString(18, true)}`,
        "bank_code": `${Utils.makeString(4, true)}-${Utils.makeString(1, true)}`,
        "bank_country": "MX",
        "currency": "MXN",
        "branch_code": "BAD345"
      }
    };

    return dataAccounts;
  }



};


module.exports = DatafakerMerchant;
