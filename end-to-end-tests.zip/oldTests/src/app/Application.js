module.exports = ({ endToEndTest }) => ({
    start: async () => {
        await endToEndTest.execute();
    }
})