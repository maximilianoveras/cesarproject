module.exports = ({
    endToEndFlow
}) => ({
    execute: async () => {
        const context = {};
        for (let flow of endToEndFlow) {
            await flow.execute(context);
            await flow.assert(context);
        }
    }
});