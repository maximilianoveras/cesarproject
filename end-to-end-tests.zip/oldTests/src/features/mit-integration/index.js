process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

import { Selector } from 'testcafe';
const fs = require('fs');
const axios = require('axios').default;

fixture`Merchant Portal Validation`;

test('File Processing', async () => {
    const fileContent = fs.readFileSync(`${__dirname}/../resource/mit-integration-model.json`, 'utf8');
    let mitIntegrationObject = JSON.parse(fileContent);

    const affSellerCode = Math.floor(Math.random() * Number("9".repeat(7)) + 1).toString().padStart(7, "0");
    const merchantName = `MIT INT TESTING ${Date.now()}`;

    mitIntegrationObject.receipt_name = merchantName;
    mitIntegrationObject.seller_code = affSellerCode;
    mitIntegrationObject.affiliations[0].affiliation_seller_code = affSellerCode;
    mitIntegrationObject.affiliations[1].affiliation_seller_code = affSellerCode;
    mitIntegrationObject.trade_name = `SELLER TESTING ${Date.now()}`;
    mitIntegrationObject.external_merchant_id = Math.floor(Math.random() * Number("9".repeat(8)) + 1).toString().padStart(8, "0");
    mitIntegrationObject.legal_document_number = `RFC${Math.floor(Math.random() * Number("9".repeat(9)) + 1).toString().padStart(9, "0")}`;
    mitIntegrationObject.merchant_name = merchantName;
    mitIntegrationObject.bank_account.name = `ACCOUNT MIT ${Date.now()}`;;
    mitIntegrationObject.bank_account.account_number = Math.floor(Math.random() * Number("9".repeat(18)) + 1).toString().padStart(18, "0");

    const response = await axios.post('https://mit-migration-orchestrator-adp-qa-plat.onboarding.qa.gms.corp/api/migrate', mitIntegrationObject);
    // console.log(response.data);

    fs.writeFileSync(`${Date.now()}.json`,JSON.stringify(mitIntegrationObject, null, 4));

});

test('Registration Checking', async t => {
    // await t
    //     .typeText('#idToken1', credentials.user)
    //     .typeText('#idToken2', credentials.pass)
    //     .click('#loginButton_0')
    //     .click(Selector('div').withAttribute('name', 'extract'))
    //     .click('#Reportes')
    //     .click(Selector('a').withText('Estado de Cuenta'))
    //     .click(Selector('div').withText('Período').sibling('div').withAttribute('name', 'direction_down'))
    //     //.click(Selector('div').withText('Últimos 60 días'))
    //     .takeScreenshot();
});