const {
    asValue,
    asFunction,
} = require('awilix');

// Load Configs
const config = require('config');

module.exports = {
    ...require('./RestClients'),
    config: asValue(config),
    restConfig: asValue(config.integration.rest),
}