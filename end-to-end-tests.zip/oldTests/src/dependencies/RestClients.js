const {
    asClass,
} = require('awilix');
const RestClients = require('@albatross/communication-clients');

module.exports = {
    domainsClient: asClass(RestClients.DomainsClient),
    mappingsClient: asClass(RestClients.MappingsClient),
    contractsClient: asClass(RestClients.ContractsClient),
    fulfillmentsClient: asClass(RestClients.FulfillmentsClient),
    fulfillmentSystemsClient: asClass(RestClients.FulfillmentSystemsClient),
    merchantsClient: asClass(RestClients.MerchantsClient),
    merchantAccountsClient: asClass(RestClients.MerchantAccountsClient),
    legalDataClient: asClass(RestClients.LegalDataClient),
    splitterClient: asClass(RestClients.SplitterClient),
    affiliationsClient: asClass(RestClients.AffiliationsClient),
    offersClient: asClass(RestClients.OffersClient),
    affiliationsConfigurationsClient: asClass(RestClients.AffiliationsConfigurationsClient),
    mdrConfigurationsClient: asClass(RestClients.MdrConfigurationsClient),
    offersPricingClient: asClass(RestClients.OffersPricingClient),
    ordersClient: asClass(RestClients.OrdersClient),
    ordersPricingConfigurationsClient: asClass(RestClients.OrdersPricingConfigurationsClient),
    productsClient: asClass(RestClients.ProductsClient),
    acquirerProductConfigurationsClient: asClass(RestClients.AcquirerProductConfigurationsClient),
    serviceProductConfigurationsClient: asClass(RestClients.ServiceProductConfigurationsClient),
    terminalProductConfigurationsClient: asClass(RestClients.TerminalProductConfigurationsClient),
    sellersClient: asClass(RestClients.SellersClient),
};