module.exports = [
    'src/steps/**/*.js',
    'src/flow/**/*.js',
    'src/app/**/*.js',
    'src/domain/**/*.js',
    'src/infra/**/*.js',
]