const {
    createContainer,
    InjectionMode
} = require('awilix');

const container = createContainer();

// Load Dynamic Dependencies Automatic
container.loadModules(require('./DynamicDependencies'), {
    formatName: 'camelCase',
    resolverOptions: {
        injectionMode: InjectionMode.PROXY
    }
});

// Load Static Dependencies
container.register(require('./StaticDependencies'));

module.exports = container;
