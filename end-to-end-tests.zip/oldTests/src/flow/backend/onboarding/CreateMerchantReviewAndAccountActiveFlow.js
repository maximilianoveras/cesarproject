const { expect } = require('chai');

module.exports = ({
    createMerchantReviewStep,
    //createMerchantAccountActiveStep,
    merchantsClient
}) => ({
    execute: async context => {
        context.merchant = await createMerchantReviewStep();
        //context.account = await createMerchantAccountActiveStep(context);
    },
    assert: async context => {
        const { data: merchant } = await merchantsClient.getById({ id: context.merchant.merchant_id });
        expect(merchant.situation.status).eq('review');
    }
})