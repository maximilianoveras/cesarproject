module.exports = ({
    merchantsClient,
    legalDataClient,
    merchantDataFaker
}) => async () => {
    
    const merchant = merchantDataFaker.generateMerchant();

    let result = await merchantsClient.create({ data: merchant });

    const createdMerchant = result.data;

    result = await merchantsClient.createQualification({ parent_id: createdMerchant.merchant_id });

    const legalData = merchantDataFaker.generateMerchantLegal();

    result = await legalDataClient.create({ 
        parent_id: createdMerchant.merchant_id,
        country: createdMerchant.country,        
        data: legalData
    });

    result = await merchantsClient.createQualification({ parent_id: createdMerchant.merchant_id });

    return createdMerchant;
}