module.exports = ({
    merchantAccountsClient,
    merchantAccountDataFaker
}) => async ({ merchant }) => {
    
    const merchantAccount = merchantAccountDataFaker.generateMerchantAccount(merchant.merchant_id);

    const { data: createdMerchantAccount } = await merchantAccountsClient.create({ data: merchantAccount });

    await merchantAccountsClient.createQualification({ parent_id: createdMerchantAccount.merchant_account_id });

    return createdMerchantAccount;
}