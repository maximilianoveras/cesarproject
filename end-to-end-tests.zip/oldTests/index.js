const { registerFlow } = require('./support/frontend/onboarding/flows');
const fs = require('fs');
const path = require('path');

(async () => {
    if (!fs.existsSync('./executionData')) {
        fs.mkdirSync('./executionData');
    }

    const scenarios = traverseDir('scenarios');
    const execEnv = process.argv[2].toUpperCase() || "DEV";

    // for (let index = 0; index < scenarios.length; index++) {
        const scenarioPath = path.resolve(scenarios[0]);
        const scenario = require(scenarioPath);

        console.log(`${0 + 1} - ${scenario.title}`);
        const merchant = scenario.data.merchant;
        await registerFlow(merchant, execEnv);
    // }
})();

function traverseDir(dir) {
    let paths = [];
    fs.readdirSync(dir).forEach(file => {
      let fullPath = path.join(dir, file);
      if (fs.lstatSync(fullPath).isDirectory()) {
         paths = paths.concat(traverseDir(fullPath));
       } else {
         paths.push(fullPath);
       }  
    });

    return paths;
  }
