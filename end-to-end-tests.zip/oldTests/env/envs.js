module.exports.envs = {
    TOKEN: {
        GENERAL: "https://api.pre.globalgetnet.com/oauth2/mx/access_token"
    },
    ONBOARDING: {
        FRONT: {
            UAT: "https://branch.pre.globalgetnet.com?code=Q09ERV9PTkJPQVJESU5H",
            LOCAL: "https://branch.pre.globalgetnet?code=Q09ERV9PTkJPQVJESU5H",
            QA: "https://onboarding-branches-qa-plat.onboarding.qa.gms.corp?code=Q09ERV9PTkJPQVJESU5H",
            DEV: "https://onboarding-branches.onboarding.dev.gms.corp?code=Q09ERV9PTkJPQVJESU5H"
        },
        BACK: {
            MXAFFILIATIONS: {
                UAT: 'https://mx-affiliations-adp-uat-sanmx.onboarding.uat.gms.corp/api/affiliations-adapter/prosa-data',
            },
            MXAFFILIATIONSADP:{
                UAT: 'https://mx-affiliations-adp-uat-sanmx.onboarding.uat.gms.corp/api/affiliations-adapter/prosa-data',
            },
            FULFILLMENTS:{
                UAT: '',
            },
            MERCHANTS:{
                UAT: 'https://api.pre.globalgetnet.com/onboarding/v1/merchants',
            },
            UAT: "https://api.pre.globalgetnet.com/onboarding",
            QA: (entity)=>{
                return `https://${entity}-ms.onboarding.qa.gms.corp/api`;
            } 
            ,
            DEV: "https://merchants-ms.onboarding.dev.gms.corp/api"
        }

    },
    SALESFORCE: {
        FRONT: {
            UAT: "https://test.salesforce.com/"
        },
        LOGIN_DATA: {
            UAT: {
                BACKOFFICE:{
                    USER: "backoffice@santander.com.preprod",
                    PASS: "teste12345"
                },
                UNDERWRITING:{
                    USER: "underwriting@santander.com.preprod",
                    PASS: "teste12345"
                }
            },
            QA: {
                BACKOFFICE:{
                    USER: "backoffice@santander.com.qa",
                    PASS: "teste1234"
                },
                UNDERWRITING:{
                    USER: "underwriting@santander.com.qa",
                    PASS: "teste1234"
                }
            }
        }
    }
}