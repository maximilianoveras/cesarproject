const Operations = require('../../../data/onboarding/Operations');
const operation = new Operations();

const getMerchantReviewAndAccountActive = async (merchantInformations) => {
  let merchant = {};

  try {

    merchant = await operation.getMerchantReview(merchantInformations);
    let accounts = [];
    for (let index = 0; index < merchantInformations.accountQuantity; index++) {
      const account = JSON.parse(await operation.createMerchantAccountActive());
      accounts.push(account);    
    }
    
    merchant = await operation.getMerchantById();
    merchant.accounts = accounts;
  
  } catch (error) {
    throw new Error('Error call apis: ', error);
  }

  return merchant;

};

const getFulfillment = async (order) => {
  return await operation.getFulfillment(order);
};

const generateFulfillment = async (order) => {
  return await operation.generateFulfillment(order);
};

const approveSeller = async (seller) => {
  return await operation.approveSeller(seller);
}

const getOrdersByMerchant = async () => {
  return await operation.getOrdersByMerchantId();
}

const getSellersByMerchantId = async () => {
  return await operation.getSellersByMerchantId();
}

module.exports = {
  getMerchantReviewAndAccountActive,
  getFulfillment,
  getOrdersByMerchant,
  generateFulfillment,
  getSellersByMerchantId,
  approveSeller
};