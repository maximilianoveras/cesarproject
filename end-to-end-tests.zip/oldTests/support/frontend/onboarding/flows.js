const {
    Builder,
    Browser,
    Options
} = require('selenium-webdriver');
const {
    OnboardingPagesController
} = require('../../pages/controllers/onboarding');
const {
    SalesforcePagesController
} = require('../../pages/controllers/salesforce');
// const { getMerchantReviewAndAccountActive, approveSeller, getFulfillment, getOrdersByMerchant, generateFulfillment, getSellersByMerchantId } = require('./apis/composite');
// const { activation, expirationDateToken } = require('../../data/payments/TerminalActivationsClient');
// const { send } = require('../../data/payments/pos-client/lib/main');
const chrome = require("selenium-webdriver/chrome");
// const { }
const fs = require('fs');
const merchantFunctions = require('../../../merchantCreation.js');
const transactions = require('../../../transaction');

const getNewDriver = async () => {
    const options = new chrome.Options();
    options.addArguments('--ignore-certificate-errors');
    options.addArguments('--ignore-ssl-errors');
    options.addArguments("--window-size=1400,600");
    options.addArguments('--trusted-download-sources');
    options.addArguments("--disable-infobars"); // disabling infobars
    options.addArguments("--disable-extensions"); // disabling extensions
    options.addArguments("--disable-gpu"); // applicable to windows os only
    options.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems
    options.addArguments("--no-sandbox"); // Bypass OS security model
    options.addArguments("--headless"); // Bypass OS security model

    options.setUserPreferences({
        'profile.default_content_setting_values.notifications': 2
    });
    const driver = new Builder()
        .forBrowser(Browser.CHROME)
        .withCapabilities(options)
        .build();

    return driver;
}

module.exports.registerFlow = async (merchant, execEnv) => {
    this.dataStoragePath = `./executionData/${Date.now()}`;
    fs.mkdirSync(this.dataStoragePath);

    // const merchantReview = await getMerchantReviewAndAccountActive(merchant);
    // merchant.clientNumber = merchantReview.external_merchant_id;

    // fs.writeFileSync(`${this.dataStoragePath}/merchant.json`, JSON.stringify(merchantReview, null, 4), "utf8");

    let driver = await getNewDriver();

    let onboardingController = new OnboardingPagesController(driver, execEnv);
    let dataMerchant = await merchantFunctions.merchantCreation();
    let comercial_name = await onboardingController.registerMerchant(merchant, dataMerchant.RFC);
    console.log(comercial_name);
    const orderNumbers = await onboardingController.getOrderNumbers();
    //const orderNumbers = [
    //    'QNLVMU5e'
    //]
    //comercial_name = 'Seguradora Aur 890';
    console.log(orderNumbers);

    let salesforceController;

    // for (let index = 0; index < orderNumbers.length; index++) {
    await driver.quit();
    driver = await getNewDriver();
    salesforceController = new SalesforcePagesController(driver);
    await salesforceController.approveOrderBackoffice(orderNumbers[orderNumbers.length - 1], comercial_name);
    await driver.quit();
    driver = await getNewDriver();
    salesforceController = new SalesforcePagesController(driver);
    await salesforceController.approveOrderUnderwriting(orderNumbers[orderNumbers.length - 1], comercial_name);
    await driver.quit();
    let seller_code = await merchantFunctions.fulfillmentGeneration(dataMerchant.merchant_id);
    await driver.sleep(3000);
    await transactions.kek(seller_code);
    // }

    // const orders = await getOrdersByMerchant();
    // fs.writeFileSync(`${this.dataStoragePath}/orders.json`, JSON.stringify(orders, null, 4), "utf8");

    // let sellers = await getSellersByMerchantId();

    // for (let index = 0; index < sellers.length; index++) {
    //     const seller = sellers[index];
    //     console.log(`Approving seller '${seller.trade_name}'...`);
    //     await approveSeller(seller);
    // }

    // await driver.sleep(1000);

    // sellers = await getSellersByMerchantId();

    // for (let index = 0; index < orders.length; index++) {
    //     const order = orders[index];

    //     await generateFulfillment(order);
    //     let trying = 1;
    //     let fulfillment = undefined;

    //     while (fulfillment == undefined) {
    //         await driver.sleep(5000);
    //         console.log(`Generating fulfillment to order '${order.order_id}' - try ${trying}`);
    //         fulfillment = await getFulfillment(order);
    //         trying++;
    //     }

    //     const prefix = `${Date.now()}`;
    //     fs.writeFileSync(`${this.dataStoragePath}/${prefix}-fullfilment.json`, JSON.stringify(fulfillment, null, 4), "utf8");

    //     const terminals = await expirationDateToken(fulfillment.seller.seller_code);
    //     fs.writeFileSync(`${this.dataStoragePath}/${prefix}-tokens.json`, JSON.stringify(terminals, null, 4), "utf8");

    //     const activations = [];

    //     for (let i = 0; i < terminals.length; i++) {
    //         const terminal = terminals[i];
    //         const actvationReturn = await activation(terminal.token.code);
    //         activations.push(actvationReturn);
    //     }

    //     fs.writeFileSync(`${this.dataStoragePath}/${prefix}-terminalActivatios.json`, JSON.stringify(activations, null, 4), "utf8");

    // const transactionDone = [];

    // for (let j = 0; j < merchant.sellers.transactions.length; j++) {
    //     const transactionData = merchant.sellers.transactions[j];
    //     const cardNumber = Buffer.from(transactionData.cardNumber, 'base64').toString('ascii');

    //     for (let y = 0; y < transactionData.amounts.length; y++) {

    //         const transactionAmt = transactionData.amounts[y];
    //         const terminal = terminals.find(terminal => terminal.connectivity == transactionData.connectivity)
    //         const transaction = {
    //             "amount": transactionAmt.amout + transactionAmt.tip,
    //             "entry_mode": "051",
    //             "terminal_code": terminal.terminal_code,
    //             "seller_code":  terminal.seller_code,
    //             "card_number": cardNumber,
    //             "exp_month": null,
    //             "exp_year": null
    //         };

    //         const transacDone = await send(transaction);

    //         transactionDone.push(transacDone);

    //     };

    //     fs.writeFileSync(`${this.dataStoragePath}/transactions-${j+1}.json`, JSON.stringify(transactionDone, null, 4), "utf8");



    // }


    // }

    // fs.writeFileSync(`${this.dataStoragePath}/sellers.json`, JSON.stringify(sellers, null, 4), "utf8");

    // await driver.close();
    // await driver.quit();
};