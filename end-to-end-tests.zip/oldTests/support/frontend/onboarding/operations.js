const { By, Key, until } = require('selenium-webdriver');
const { envs } = require('../../../env/envs');
const { elements } = require('./elements');
const { getNewAffiliation } = require('../utils/getAffiliation');

module.exports.doLogin = async (driver, clientNumber) => {
    await driver.get(envs.ONBOARDING.UAT);

    await driver.wait(until.elementLocated(By.xpath(elements.LOGIN.LABELS.CLIENT_NUMBER.X_PATH))).click();
    await driver.findElement(By.xpath(elements.LOGIN.INPUTS.CLIENT_NUMBER.X_PATH)).sendKeys(clientNumber);
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.xpath(`//span[contains(text(), 'Continuar')]`))).click();
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.xpath(`//span[contains(text(), 'Continuar')]`))).click();

};

module.exports.accountPageShooping = async (driver, products) => {
    const button = await driver.wait(until.elementLocated(By.xpath(elements.ACCOUNT_PAGE.BUTTONS.SHOPPING.X_PATH)));
    await button.click();
    await driver.sleep(2000);
    await asyncForEach(products, async (product) => {
        let itemIdex;

        if (product.tip && product.gprs) {
            itemIdex = 0;
        }
        else if (product.tip && product.wifi) {
            itemIdex = 1;
        } else if (product.gprs) {
            itemIdex = 2;
        } else if (product.wifi) {
            itemIdex = 3;
        }
        else {
            throw new Error(`No product defined: ${JSON.stringify(product)}`);
        }

        // Add product
        for (let index = 0; index < product.quantity; index++) {
            await driver.sleep(1000);
            const items = await driver.findElements(By.xpath(`//p[@class='add-btn']`));
            await items[itemIdex].click(); 
        }


    });

    await driver.sleep(1000);
    let btnContinue = await driver.wait(until.elementLocated(By.xpath(elements.PRODUCT_PAGE.BUTTONS.CONTINUE.X_PATH)));
    await btnContinue.click();

    // New affiliation button
    await driver.wait(until.elementLocated(By.xpath(`//span[contains(text(), 'Nueva afiliación')]`))).click();

    const affiliationInfo = getNewAffiliation();
    const fieldNames = Object.keys(affiliationInfo);

    await driver.wait(until.elementLocated(By.xpath('/html/body/div/div[2]/div[3]/form/div[1]/div[1]/div')));
    await asyncForEach(fieldNames, async (fieldName) => {
        await setValue(elements.NEW_AFFILIATION_PAGE.INPUTS[fieldName].X_PATH, affiliationInfo[fieldName], driver);
    });

    btnContinue = await driver.wait(until.elementLocated(By.xpath(elements.NEW_AFFILIATION_PAGE.BUTTONS.CONTINUE.X_PATH)));
    await btnContinue.click();

    // Mark check buttons

    await driver.sleep(2000);
    const checks = await driver.findElements(By.xpath('//span[@class="checkbox-children"]'));

    checks.forEach(check => {
        check.click();
    });

    btnContinue = await driver.wait(until.elementLocated(By.xpath(elements.CONTACT_PAGE.BUTTONS.CONTINUE.X_PATH)));
    await btnContinue.click();

    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.xpath(`//span[contains(text(), 'Continuar')]`))).click();

    await driver.sleep(1000);
    const affiliations = await driver.findElements(By.xpath("//input[@type='radio']"));
    await affiliations.pop().click();
    await driver.wait(until.elementLocated(By.xpath(`//span[contains(text(), 'Continuar')]`))).click();
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.xpath(`//span[contains(text(), 'Imprimir')]`))).click();
    await driver.sleep(2000);
    driver.executeScript("window.scrollBy(0,100)");
    await driver.wait(until.elementLocated(By.xpath(`//span[contains(text(), 'Finalizar Compra')]`))).click();
    await driver.sleep(1000);
    await driver.wait(until.elementLocated(By.xpath(`//span[contains(text(), 'Continuar')]`))).click();

};

module.exports.closeDriver = async (driver) => {
    if (driver) {
        await driver.quit();
    }
};

module.exports.continueFlow = async (driver, xPath) => {
    const continueButton = await driver.wait(until.elementLocated(By.xpath(xPath)));
    await continueButton.click();
}

async function asyncForEach(array, callback) {
    for (let index = 0; index < array.length; index++) {
        await callback(array[index], index, array);
    }
}

async function setValue(xPath, value, driver) {
    driver.executeScript("window.scrollBy(0,40)");
    const input = await driver.wait(until.elementLocated(By.xpath(xPath)));
    await input.sendKeys(value);
}


