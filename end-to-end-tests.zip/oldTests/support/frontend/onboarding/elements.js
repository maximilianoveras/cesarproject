module.exports.elements = {
    LOGIN: {
        LABELS: {
            CLIENT_NUMBER: {
                X_PATH: "/html/body/div/div[2]/div[2]/div/div/div/button[1]/div/span"
            }
        }
        ,
        INPUTS: {
            CLIENT_NUMBER: {
                X_PATH: "/html/body/div/div[2]/div[2]/div/div/form/label/div[2]/div/input"
            }
        },
        BUTTONS: {
            CONTINUE: {
                X_PATH: "/html/body/div/div[2]/div[2]/div/div/button"
            }
        }

    },
    MERCHANT_PAGE: {
        BUTTONS: {
            CONTINUE: {
                X_PATH: "/html/body/div/div[2]/div[3]/div[2]/button"
            }
        }
    },
    ACCOUNT_PAGE: {
        BUTTONS: {
            SHOPPING: {
                X_PATH: "/html/body/div/div[2]/div[3]/div/div/div[1]/a/button"
            }
        }
    },
    PRODUCT_PAGE: {
        BUTTONS: {
            CONTINUE: {
                X_PATH: "/html/body/div/div[2]/div[6]/div[2]/button"
            } 
        },
        PRODUTS: {
            POS_GPRS: {
                X_PATH: "/html/body/div/div[2]/div[4]/div[1]/div[2]/div[3]/div/div[2]/div/p[2]"
            },
            POS_WIFI: {
                X_PATH: "/html/body/div/div[2]/div[4]/div[1]/div[2]/div[4]/div/div[2]/div/p[2]"
            },
            POS_WIFI_TIP: {
                X_PATH: "/html/body/div/div[2]/div[4]/div[1]/div[2]/div[1]/div/div[2]/div/p[2]"
            },
            POS_GPRS_TIP: {
                X_PATH: "/html/body/div/div[2]/div[4]/div[1]/div[2]/div[2]/div/div[2]/div/p[2]"
            }
        }
    },
    AFFILIATION_PAGE: {
        BUTTONS: {
            NEW: {
                X_PATH: "/html/body/div/div[2]/div[4]/div/div[1]/div[1]/div[2]/div[3]/a/button"
            },

        }
    },

    NEW_AFFILIATION_PAGE: {
        BUTTONS: {
            CONTINUE: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[2]/div/button[2]"
            },
            
        },
        INPUTS: {
            TRADE_NAME: {
                X_PATH: "/html/body/div/div[2]/div[3]/form/div[1]/div[1]/div/div/div[1]/div/div/label/div[2]/div/input"
            },
            RECEIPT_NAME: {
                X_PATH: "/html/body/div/div[2]/div[3]/form/div[1]/div[1]/div/div/div[2]/div/div/label/div[2]/div/input"
            },
            ADDRESS_STREET: {
                X_PATH: "/html/body/div/div[2]/div[3]/form/div[1]/div[1]/div/div/div[3]/div/div/label/div[2]/div/input"
            },
            ADDRESS_NUMBER: {
                X_PATH: "/html/body/div/div[2]/div[3]/form/div[1]/div[1]/div/div/div[3]/div[1]/div/label/div[2]/div/input"
            },
            ADDRESS_REFERENCE_1: {
                X_PATH: "/html/body/div/div[2]/div[3]/form/div[1]/div[1]/div/div/div[3]/div[2]/div/label/div[1]/div/input"
            },
            ADDRESS_REFERENCE_2: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[4]/div/div/label/div[1]/div/input"
            },
            ADDRESS_POSTAL_CODE: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[5]/div/div/label/div[1]/div/input"
            },
            ADDRESS_STATE: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[6]/div[1]/div/label/div[1]/div/input"
            },
            ADDRESS_CITY: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[6]/div[2]/div/label/div[1]/div/input"
            },
            ADDRESS_DISTRICT: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[7]/div/div/label/div[1]/div/input"
            },

            // ADDRESS_COMPROVANT: {
            //     X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[8]/div/div/label/div[2]/div/input"
            // },
            DDI: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[10]/div[2]/div[1]/div/label/div[1]/div/input"
            },
            AREA_CODE: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[10]/div[2]/div[2]/div/label/div[1]/div/input"
            },
            PHONE_NUMBER: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[10]/div[2]/div[3]/div/label/div[1]/div/input"
            },
            DESCRIPTION: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[11]/div/div/div/textarea"
            },
            DOCUMENT_TYPE: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/select[1]"
            },
            COMPROVANT: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[8]/div/div/label/div[2]/div/input"
            },
            OPENING: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[12]/div[1]/div/label/div[1]/div/input"
            },
            CLOSING: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[12]/div[2]/div/label/div[1]/div/input"
            },
            WEB_SITE: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[1]/div[1]/div/div/div[13]/div/div/label/div[2]/div/input"
            }
        }
    },

    CONTACT_PAGE: {
        BUTTONS: {
            CONTINUE: {
                X_PATH: "/html/body/div/div[2]/div[4]/form/div[2]/div/button[2]"
            }
        }
    }
};