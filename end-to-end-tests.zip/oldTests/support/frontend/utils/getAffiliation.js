
module.exports.getNewAffiliation = () => {
    return {
        TRADE_NAME: "TN TESTES E2E",
        RECEIPT_NAME: "RN TESTES E2E",
        ADDRESS_STREET: "RUA ACAPULCO",
        ADDRESS_NUMBER: "123",
        ADDRESS_REFERENCE_1: "QUADRA 1",
        ADDRESS_REFERENCE_2: "QUADRA 2",
        ADDRESS_POSTAL_CODE: "35169",
        ADDRESS_STATE: "CIDADE DO MÉXICO",
        ADDRESS_CITY: "CIDADE DO MÉXICO",
        ADDRESS_DISTRICT: "CIDADE DO MÉXICO",
        DDI: "91",
        AREA_CODE: "123",
        PHONE_NUMBER: "123456789",
        DESCRIPTION: "DESCRIPTION TESTES E2E",
        DOCUMENT_TYPE: "2",
        COMPROVANT: "Comprobante",
        OPENING:"0800",
        CLOSING: "1200",
        WEB_SITE: "comercio@com.mx"
    };
}
