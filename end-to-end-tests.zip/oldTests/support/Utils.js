const { doRequest, methods } = require('./request/request');
const { envs } = require('../env/envs');
class Utils {

  static async getToken() {
    const body = {
      grant_type: "client_credentials",
      client_id: "qa-id",
      client_secret: "qa-secret",
      scope: "token"
    };

    const headers = {
      "Content-Type": "application/x-www-form-urlencoded",
      "Accept": "*/*"
    };

    const token = await doRequest(envs.TOKEN.GENERAL, methods.POST, { headers: headers, form: body });

    return JSON.parse(token).access_token;
  }

  static makeString(length = 18, onlyNumbers = false, onlyCharacters) {
    let result = '';
    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    let numbers = '0123456789';
    let base = `${characters}${numbers}`;
    if (onlyNumbers) {
      base = numbers;
    }
    else if (onlyCharacters) {
      base = characters;
    }

    for (let i = 0; i < length; i++) {
      result += base.charAt(~~(Math.random() * base.length));
    }
    return result;
  }

  static generateDateISO (start, end) {
    const date = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
    return date.toISOString().substring(0, 10);
  }

  static generateExternalContactId(len = 8) {
    const str = String(new Date().getTime());
    return str.substring(str.length - len, str.length);
  }

  static makeNumber(n = 20) {
    return ~~(Math.random() * n);
  }

  static compareMsgs(arrMsgsExpected, arrReceived, ...args) {
    const prop = args.find(el => typeof el === 'string') || 'message';
    const bool = args.find(el => typeof el === 'boolean');
    const compareEqual = typeof bool !== 'undefined' ? bool : true;

    if (arrMsgsExpected.length !== arrReceived.length) return false;

    return arrReceived.every(obj => {
      const valReceived = prop === 'message' ? obj[prop].replace(/\"/g, '') : obj[prop];
      if (typeof obj !== 'object') return arrMsgsExpected.some(valExpected => obj === valExpected);
      if (!compareEqual) return arrMsgsExpected.some(valExpected => valReceived.includes(valExpected));
      return arrMsgsExpected.some(valExpected => valReceived === valExpected);
    });
  }

  static uuidv4() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      let r = Math.random() * 16 | 0,
        v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  static makeLegalDocument() {
    const numbers = '0123456789';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const threeOrFour = ~~(Math.random() * (5 - 3)) + 3;
    let res = '';
    for (let i = 0; i < (threeOrFour + 9); i++) {
      if (i < threeOrFour) res += chars.charAt(~~(Math.random() * chars.length));
      else if (i < (threeOrFour + 6)) res += numbers.charAt(~~(Math.random() * numbers.length));
      else res += `${chars}${numbers}`.charAt(~~(Math.random() * `${chars}${numbers}`.length));
    }
    return res;
  }

  static getMonth(date) {
    const month = date.getMonth() + 1;
    return (month < 10 ? '0' : '') + month;
  }

  static getDay(date) {
    return (date.getDate() < 10 ? '0' : '') + date.getDate();
  }

  static randomDate(start, end) {
    const date = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
    return `${date.getFullYear().toString().substr(-2)}${this.getMonth(date)}${this.getDay(date)}`;
  }

  static generateValidRFC(personType = "fisic", year = 1950) {
    return `${this.makeString(personType == "fisic" ? 4: 3, false, true).toUpperCase()}${this.randomDate(new Date(year, 0, 1), new Date(2001, 0, 1))}${Utils.makeString(3).toUpperCase()}`;
  }

  static documentDate(legal_document_number) {
    if (!legal_document_number || legal_document_number < 12)
      return legal_document_number;
    const date = legal_document_number.length === 13 ? legal_document_number.substring(4, 10) : legal_document_number.substring(3, 9);
    const year = date.substring(0, 2);
    const month = date.substring(2, 4);
    const day = date.substring(4);
    return new Date(year + '-' + month + '-' + day);
  }
};

module.exports = Utils;