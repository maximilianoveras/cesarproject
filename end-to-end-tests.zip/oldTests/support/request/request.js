const request = require('request');

module.exports.methods = {
    POST: "POST",
    GET: "GET",
    PUT: "PUT",
    PATCH: "PATCH"
}

module.exports.doRequest = (uri, method = this.methods.GET, additionals = {}) => {
    return new Promise(function (resolve, reject) {

        let options = {
            uri: uri,
            method: method
        };

        if (additionals.json) {
            options.json = additionals.json;
        }

        if (additionals.headers) {
            options.headers = additionals.headers;
        }

        if (additionals.form) {
            options.form = additionals.form;
        }

        request(options,
            (error, response, body) => {
                if (error) {
                    reject(error);
                }
                resolve(body);
            });

    });
};
