const {Base} = require('../base');

module.exports.LoginPage = class extends Base {
    constructor(driver) {
        super(driver);
        this.user = this.By.id("username");
        this.password = this.By.id("password");
        this.loginButton = this.By.id("Login");
    }

    async doLogin(profile) {
        await this.setContent(this.user, profile.USER);
        await this.setContent(this.password, profile.PASS);
        await this.click(this.loginButton, this.sleep.LOW);
    }

}