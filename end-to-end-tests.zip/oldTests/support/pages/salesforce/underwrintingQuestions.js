const { Base } = require('../base');
const d = require('selenium-webdriver');

const ANSWER = {
    YES: "yes",
    NO: "no",
    SOFT: "soft",
    HARD: "hard",
    NONE: "none",
    I: "I",
    II: "II",
    III: "III",
    ZERO: "ZERO",
    ONE: "ONE",
    TWO: "TWO"
};

const ANSWER_MODEL = {
    APPROVE: {
        1: ANSWER.NO,
        2: ANSWER.NO,
        3: ANSWER.NO,
        4: ANSWER.NO,
        5: ANSWER.NO,
        6: ANSWER.NO,
        7: ANSWER.NO,
        8: ANSWER.YES,
        9: ANSWER.NO,
        10: ANSWER.YES,
        11: ANSWER.YES,
        12: ANSWER.YES,
        13: ANSWER.YES,
        14: ANSWER.NO,
        15: ANSWER.YES,
        16: {type: "numberInformation", value:"484"},
        17: {type: "numberInformation", value:"3"},
        18: {type: "numberInformation", value:"2"},
        19: {type: "numberInformation", value:"4"},
        20: ANSWER.II,
        21: {type: "numberInformation", value:"5"},
        22: {type: "dateInformation", value:"diciembre 2, 2019"},
        23: {type: "numberInformation2", value:"54"},
        24: {type: "justification", answer: "soft", justification: "2500000"},
        25: {type: "justification", answer: "hard", justification: "1000000000"},
        26: ANSWER.ONE,
        27: {type: "justification", answer: "soft", justification: "100000"},
        28: ANSWER.NO,
        29: {type: "literalInformation", value:"Sin comentarios"},
        30: {type: "literalInformation", value:"Sin comentarios"},
        31: ANSWER.YES,
    },
    // APPROVE: {
    //     1: ANSWER.YES,
    //     2: ANSWER.YES,
    //     3: ANSWER.YES,
    //     4: ANSWER.YES,
    //     5: ANSWER.YES,
    //     6: ANSWER.YES,
    //     7: ANSWER.YES,
    //     8: ANSWER.YES,
    //     9: ANSWER.NO,
    //     10: ANSWER.YES,
    //     11: ANSWER.YES,
    //     12: ANSWER.YES,
    //     13: ANSWER.YES,
    //     14: ANSWER.YES,
    //     15: ANSWER.YES,
    //     16: { type: "numberInformation", value: "484" },
    //     17: { type: "numberInformation", value: "3" },
    //     18: { type: "numberInformation", value: "2" },
    //     19: { type: "numberInformation", value: "4" },
    //     20: ANSWER.II,
    //     21: { type: "numberInformation", value: "5" },
    //     22: { type: "dateInformation", value: "diciembre 2, 2019" },
    //     23: { type: "numberInformation2", value: "54" },
    //     24: { type: "justification", answer: "soft", justification: "2500000" },
    //     25: { type: "justification", answer: "hard", justification: "1000000000" },
    //     26: ANSWER.ONE,
    //     27: { type: "justification", answer: "soft", justification: "100000" },
    //     28: ANSWER.YES,
    //     29: { type: "literalInformation", value: "Sin comentarios" },
    //     30: { type: "literalInformation", value: "Sin comentarios" },
    //     31: ANSWER.NO,
    // },
    REPPROVE: {
        1: ANSWER.YES,
        2: ANSWER.NO,
        3: ANSWER.YES,
        4: ANSWER.NO,
        5: ANSWER.NO,
        6: ANSWER.NO,
        7: ANSWER.YES,
        8: ANSWER.YES,
        9: ANSWER.NO,
        10: ANSWER.YES,
        11: ANSWER.YES,
        12: ANSWER.YES,
        13: ANSWER.YES,
        14: ANSWER.NO,
        15: ANSWER.YES,
        16: { type: "numberInformation", value: "484" },
        17: { type: "numberInformation", value: "3" },
        18: { type: "numberInformation", value: "2" },
        19: { type: "numberInformation", value: "4" },
        20: ANSWER.II,
        21: { type: "numberInformation", value: "5" },
        22: { type: "dateInformation", value: "diciembre 2, 2019" },
        23: { type: "numberInformation", value: "54" },
        24: { type: "numberInformation", value: "2500000" },
        25: ANSWER.SOFT,
        26: { type: "numberInformation", value: "1000000000" },
        27: ANSWER.HARD,
        28: ANSWER.ONE,
        29: { type: "numberInformation", value: "10000000" },
        30: ANSWER.SOFT,
        31: ANSWER.YES,
        32: { type: "literalInformation", value: "Sin comentarios" },
        33: { type: "literalInformation", value: "Sin comentarios" },
        34: ANSWER.YES,
    }
}

module.exports.UnderwritingQuestionsPage = class extends Base {
    constructor(driver) {
        super(driver);
        this.acceptButton = this.By.xpath("//button[@title = 'Aceptar']");
        this.nextButton = this.By.xpath("//button[@title='Siguiente']");
        this.backButton = this.By.xpath("//button[@title='Volver']");
        this.numberInformation = this.By.xpath("//input[@name = 'number']");
        this.dateInformation = this.By.xpath("//input[@name = 'date']");
        this.literalInformation = this.By.xpath("//textarea[@name = 'textarea']");
        this.seguint = this.By.xpath("/html/body/div[4]/div[1]/section/div[1]/div[2]/div[2]/div[1]/div/div/div/div/div/one-record-home-flexipage2/forcegenerated-adgrollup_component___forcegenerated__flexipage_recordpage___underwriting___case___view/forcegenerated-flexipage_underwriting_case__view_js/record_flexipage-record-page-decorator/div[1]/slot/flexipage-record-home-left-sidebar-template-desktop2/div/div[2]/div[1]/slot/slot/flexipage-component2[1]/slot/flexipage-aura-wrapper/div/c-questions/div/lightning-textarea/div[1]/textarea")
        this.written = this.By.xpath("//button[@title='Siguiente']");

        this.answerButtons = {
            yes: this.By.xpath("//input[contains(@value, 'Sí')]"),
            no: this.By.xpath("//input[contains(@value, 'No')]"),
            soft: this.By.xpath("//input[contains(@value, 'Soft')]"),
            hard: this.By.xpath("//input[contains(@value, 'Hard')]"),
            none: this.By.xpath("//input[contains(@value, 'None')]"),
            I: this.By.xpath("//input[contains(@value, 'I')]"),
            II: this.By.xpath("//input[contains(@value, 'II')]"),
            III: this.By.xpath("//input[contains(@value, 'III')]"),
            ZERO: this.By.xpath("//input[contains(@value, '0')]"),
            ONE: this.By.xpath("//input[contains(@value, '1')]"),
            TWO: this.By.xpath("//input[contains(@value, '2')]"),
        };
        this.saveButton = this.By.xpath("//button[@title = 'Guardar']");
    }

    async answerQuestion(action = "APPROVE") {
        const answers = ANSWER_MODEL[action];
        await this.click(this.acceptButton, 0, false, true);
        const quantity = Object.keys(answers).length;
        for (let index = 1; index <= quantity; index++) {
            await this.driver.sleep(3000);
            const answer = answers[index];
            const isChekQuestion = this.answerButtons[answer] != undefined;
            console.log(answers[index]);
            if (isChekQuestion) {
                await this.click(this.answerButtons[answer], this.sleep.LOW, false, true);
                // if (index === 1 || index === 2 || index === 3 || index === 4 || index === 5 || index === 6 || index === 7 || index === 14 || index === 28 || index === 31) {
                //     await this.driver.sleep(3000);
                //     let text = `kekekek`
                //     await this.getElement(this.seguint)
                //     await this.clear(this.seguint);
                //     await this.click(this.seguint, this.sleep.LOW, false, true);
                //     await this.setContent(this.seguint, text);
                //     await this.click(this.written, this.sleep.LOW, false, true);
                // }
            }
            else if (answer.type === 'justification') {
                await this.click(this.answerButtons[answer.answer], this.sleep.LOW, false, true);
                this.textArea = this.By.xpath("/html/body/div[4]/div[1]/section/div[1]/div[2]/div[2]/div[1]/div/div/div/div/div/one-record-home-flexipage2/forcegenerated-adgrollup_component___forcegenerated__flexipage_recordpage___underwriting___case___view/forcegenerated-flexipage_underwriting_case__view_js/record_flexipage-record-page-decorator/div[1]/slot/flexipage-record-home-left-sidebar-template-desktop2/div/div[2]/div[1]/slot/slot/flexipage-component2[1]/slot/flexipage-aura-wrapper/div/c-questions/div/lightning-input/div[1]/input");
                await this.getElement(this.textArea)
                await this.clear(this.textArea);
                await this.click(this.textArea, this.sleep.LOW, false, true);
                await this.setContent(this.textArea, answer.justification);
                await this.click(this.nextButton, this.sleep.LOW, false, true);
                await this.driver.sleep(3000);
            }
            else if (answer.type === 'numberInformation') {
                this.textArea = this.By.xpath("/html/body/div[4]/div[1]/section/div[1]/div[2]/div[2]/div[1]/div/div/div/div/div/one-record-home-flexipage2/forcegenerated-adgrollup_component___forcegenerated__flexipage_recordpage___underwriting___case___view/forcegenerated-flexipage_underwriting_case__view_js/record_flexipage-record-page-decorator/div[1]/slot/flexipage-record-home-left-sidebar-template-desktop2/div/div[2]/div[1]/slot/slot/flexipage-component2[1]/slot/flexipage-aura-wrapper/div/c-questions/div/lightning-input/div[1]/input");
                await this.getElement(this.textArea)
                await this.clear(this.textArea);
                await this.click(this.textArea, this.sleep.LOW, false, true);
                await this.setContent(this.textArea, answer.value);
                await this.click(this.nextButton, this.sleep.LOW, false, true);
                await this.driver.sleep(3000);
            }
            else if (answer.type === 'numberInformation2') {
                await this.click(this.nextButton, this.sleep.LOW, false, true);
                await this.driver.sleep(3000);
            }
            else if (answer.type === 'dateInformation') {
                this.textArea = this.By.xpath("/html/body/div[4]/div[1]/section/div[1]/div[2]/div[2]/div[1]/div/div/div/div/div/one-record-home-flexipage2/forcegenerated-adgrollup_component___forcegenerated__flexipage_recordpage___underwriting___case___view/forcegenerated-flexipage_underwriting_case__view_js/record_flexipage-record-page-decorator/div[1]/slot/flexipage-record-home-left-sidebar-template-desktop2/div/div[2]/div[1]/slot/slot/flexipage-component2[1]/slot/flexipage-aura-wrapper/div/c-questions/div/lightning-input/lightning-datepicker/div[1]/div/input");
                const textA = await this.getElement(this.textArea);
                await this.clear(this.textArea);
                await this.click(this.textArea, this.sleep.LOW, false, true);
                await this.setContent(this.textArea, answer.value);
                await textA.sendKeys(d.Key.TAB);
                // this.kek = this.By.xpath("//button[@title='Siguiente']");
                // await this.getElement(this.kek).sendKeys('webdriver', d.Key.ENTER);
                // await this.click(this.backButton, this.sleep.LOW, false, true);
                // await this.driver.sleep(3000);
                // await this.click(this.nextButton, this.sleep.LOW, false, true);
                // await this.driver.sleep(3000);
                await this.click(this.nextButton, this.sleep.LOW, false, true);
                await this.driver.sleep(3000);
            }
            else if (answer.type === 'literalInformation') {
                this.textArea = this.By.xpath("/html/body/div[4]/div[1]/section/div[1]/div[2]/div[2]/div[1]/div/div/div/div/div/one-record-home-flexipage2/forcegenerated-adgrollup_component___forcegenerated__flexipage_recordpage___underwriting___case___view/forcegenerated-flexipage_underwriting_case__view_js/record_flexipage-record-page-decorator/div[1]/slot/flexipage-record-home-left-sidebar-template-desktop2/div/div[2]/div[1]/slot/slot/flexipage-component2[1]/slot/flexipage-aura-wrapper/div/c-questions/div/lightning-textarea/div/textarea");
                await this.getElement(this.textArea)
                await this.clear(this.textArea);
                await this.click(this.textArea, this.sleep.LOW, false, true);
                await this.setContent(this.textArea, answer.value);
                await this.click(this.nextButton, this.sleep.LOW, false, true);
                await this.driver.sleep(3000);
            }

            // await this.click(this.nextButton, 0, false, true);
        }

        await this.save();
    }

    async save() {
        await this.getElement(this.By.xpath("//b[text()='Listas']"));
        await this.getElement(this.saveButton);
        await this.click(this.saveButton, 0, false, true);
        await this.getElement(this.By.xpath("//b[text()='Listas']"));
    }
};