const {
    Base
} = require('../base');


const ANSWER = {
    YES: "yes",
    NO: "no",
    WRITTEN: "written"
};
const ANSWER_MODEL = {
    APPROVE: {
        1: ANSWER.YES,
        2: ANSWER.YES,
        3: ANSWER.YES,
        4: ANSWER.YES,
        5: ANSWER.YES,
        6: ANSWER.YES,
        7: ANSWER.YES,
        8: ANSWER.YES,
        9: ANSWER.YES,
        10: ANSWER.YES,
        11: ANSWER.WRITTEN
    },
    REPPROVE: {
        1: ANSWER.YES,
        2: ANSWER.YES,
        3: ANSWER.NO,
        4: ANSWER.YES,
        5: ANSWER.YES,
        6: ANSWER.YES,
        7: ANSWER.YES,
        8: ANSWER.YES,
        9: ANSWER.YES,
        10: ANSWER.YES,
        11: ANSWER.YES,
        12: ANSWER.NO,
        13: ANSWER.NO,
        14: ANSWER.NO,
        15: ANSWER.WRITTEN
    }
}

module.exports.BackofficeQuestionsPage = class extends Base {
    constructor(driver) {
        super(driver);
        this.acceptButton = this.By.xpath("//button[@title = 'Aceptar']");
        this.textArea = this.By.xpath("//textarea[@class='slds-textarea']");
        this.written = this.By.xpath("//button[@title='Siguiente']");
        this.yes = this.By.xpath("//input[contains(@value, 'Sí')]");
        this.no = this.By.xpath("//input[contains(@value, 'No')]");
        this.saveButton = this.By.xpath("//button[@title = 'Guardar']");
        this.seguint = this.By.xpath("/html/body/div[4]/div[1]/section/div[1]/div[2]/div[2]/div[1]/div/div/div/div/div/one-record-home-flexipage2/forcegenerated-adgrollup_component___forcegenerated__flexipage_recordpage___backoffice___case___view/forcegenerated-flexipage_backoffice_case__view_js/record_flexipage-record-page-decorator/div[1]/slot/flexipage-record-home-left-sidebar-template-desktop2/div/div[2]/div[1]/slot/slot/flexipage-component2[1]/slot/flexipage-aura-wrapper/div/c-questions/div/lightning-textarea/div[1]/textarea")
    }

    async answerQuestion(action = "APPROVE") {
        const answers = ANSWER_MODEL[action];

        await this.click(this.acceptButton, 0, false, true);
        const quantity = Object.keys(answers).length;
        await this.driver.sleep(this.sleep.LOW);

        for (let index = 1; index <= quantity; index++) {
            await this.driver.sleep(3000);
            console.log(answers[index]);
            if (answers[index] === 'written') {
                const text = 'saidsaidsaid'
                await this.getElement(this.textArea)
                await this.clear(this.textArea);
                await this.click(this.textArea, this.sleep.LOW, false, true);
                await this.setContent(this.textArea, text);
            }
            await this.driver.sleep(3000);
            await this.click(this[answers[index]], 0, false, true);
            if (answers[index] === 'no') {
                await this.driver.sleep(3000);
                let text = `kekekek`
                await this.getElement(this.seguint)
                await this.clear(this.seguint);
                await this.click(this.seguint, this.sleep.LOW, false, true);
                await this.setContent(this.seguint, text);
                await this.click(this.written, this.sleep.LOW, false, true);
            }
        }

        await this.save();
        // await this.getElement(this.acceptButton);
        // console.log(`kkekeekekeke`)
    }

    async save() {
        await this.getElement(this.By.xpath("//b[text()='Identificacion oficial de los REP LEGALES']"));
        await this.getElement(this.saveButton);
        await this.click(this.saveButton, this, false, true);
        await this.getElement(this.By.xpath("//lightning-formatted-text[text()='Aprobado']"))
    }
};