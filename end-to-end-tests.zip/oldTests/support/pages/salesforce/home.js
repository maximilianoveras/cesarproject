const { Base } = require('../base');

module.exports.HomePage = class extends Base {
    constructor(driver) {
        super(driver);
        this.searchIput = this.By.xpath("//input[@title='Buscar...']");
        this.searchScopeInput = this.By.xpath("//input[@id='169:0;p']/..");
        this.searchScopeOption = this.By.xpath("//span[@title='<scope>']");
    }

    async search(text, scope = "Todos") {
         await this.getElement(this.searchScopeInput);
        let scopeButton = Object.assign({}, this.searchScopeOption);
        scopeButton.value = scopeButton.value.replace('<scope>', scope);

        let found = false;
        do {
            console.log(`Searching '${text}' case...`);
            await this.getElement(this.searchIput)
            await this.click(this.searchScopeInput, 0, false, true);
            // await this.click(scopeButton, 0, false, true);
            await this.clear(this.searchIput);
            await this.click(this.searchIput, this.sleep.LOW, false, true);
            await this.setContent(this.searchIput, text);
            await this.setContent(this.searchIput, this.Key.ENTER);
            await this.driver.sleep(3000);
            found = await this.driver.executeScript(`return document.querySelector(".noResultsTitle");`);
        } while (found != null);
    }

    async selectOrder(affiliationName) {
        // await this.driver.sleep(3000);
        await this.driver.sleep(this.sleep.LOW);
        const element = await this.getElement(this.By.xpath(`//td/span/a[contains(text(), '${affiliationName}')]/../../preceding::th[1]/span/a`));
        const html = await element.getAttribute('innerHTML');
        console.log(html);
        await this.click(this.By.xpath(`//td/span/a[contains(text(), '${affiliationName}')]/../../preceding::th[1]/span/a`));
    }
}