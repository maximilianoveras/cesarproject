const { LoginPage } = require('../salesforce/login');
const { HomePage } = require('../salesforce/home');
const { BackofficeQuestionsPage} = require('../salesforce/backofficeQuestions');
const { UnderwritingQuestionsPage } = require('../salesforce/underwrintingQuestions');
const { envs } = require('../../../env/envs');

module.exports.SalesforcePagesController = class {
    constructor(driver) {
        this.setDriver(driver);     
        this.open();
    }

    async setDriver(driver) {
        this.driver = driver;
        this.login = new LoginPage(driver);
        this.home = new HomePage(driver);
        this.backofficeQuestions = new BackofficeQuestionsPage(driver);
        this.underwritingQuestions = new UnderwritingQuestionsPage(driver);
    }

    async open() {
        await this.driver.navigate().to(envs.SALESFORCE.FRONT.UAT);
    }

    async approveOrderBackoffice(orderNumber, affiliationName) {
       await this.login.doLogin(envs.SALESFORCE.LOGIN_DATA.UAT.BACKOFFICE);
       await this.home.search(orderNumber/*, "Casos"*/);
       await this.home.selectOrder(affiliationName);
       await this.backofficeQuestions.answerQuestion();
    //    await this.doLogout();
    }

    async approveOrderUnderwriting(orderNumber, affiliationName) {
        await this.login.doLogin(envs.SALESFORCE.LOGIN_DATA.UAT.UNDERWRITING);
        await this.home.search(orderNumber/*, "Casos"*/);
        // console.log(`kwkwkwkwkkwkw`)
        // await this.driver.sleep(3000);
        // console.log(`kekekekekkeke`)
        await this.home.selectOrder(affiliationName);
        await this.underwritingQuestions.answerQuestion();
        await this.doLogout();
     }

    async doLogout() {
        await this.driver.navigate().to('https://getnet--preprod.lightning.force.com/secur/logout.jsp');
        await this.driver.sleep(2000);
    }
}