const { HomePage } = require('../onboarding/home');
const { LoginPage } = require('../onboarding/login');
const { AccountPage } = require('../onboarding/account');
const { AffiliationChoicePage } = require('../onboarding/affiliationChoice');
const { ProductSelectionPage } = require('../onboarding/produtSelection');
const { AffiliationRegisterPage } = require('../onboarding/affiationRegister');
const { ContactPage } = require('../onboarding/contact');
const { AffiliationSumaryPage } = require('../onboarding/affiliationSumary');
const { SumaryPage } = require('../onboarding/sumary');
const { OrderPage } = require('../onboarding/order');
const { envs } = require('../../../env/envs');
const { LegalData } = require('../onboarding/legalData');

module.exports.OnboardingPagesController = class {
    constructor(driver, execEnv) {
        this.setDriver(driver);
        this.execEnv = execEnv;
        this.open();
    }

    async open() {
        await this.driver.get(envs.ONBOARDING.FRONT[this.execEnv]);
    }

    async registerMerchant(merchant, RFC) {
        if (merchant.personType == "fisic") {
            merchant.comprovants.splice(merchant.comprovants.findIndex(comp => comp.name == "legalDocument"), 1);
        }

        await this.login.doLoginByBUC(RFC);
        // console.log(`kekeke1`)
        await this.home.verifyLegalData();
        // console.log(`kekeke2`)
        // if (!this.home.legalDataIsOk) {
            // await this.home.click(this.home.legalRepresentativeEditButton);
            // console.log(`kekeke3`)
            // await this.legalData.setLegalData(merchant.legalData);
            // console.log(`kekeke4`)
            // await this.legalData.continue();
        // }
        
        await this.home.addComprovants(merchant.comprovants);
        await this.driver.sleep(3000);
        await this.home.continue();

        for (let index = 0; index < merchant.sellers.length; index++) {
            const seller = merchant.sellers[index];
            let comercial_name = await this.addSeller(seller, index);
            await this.driver.sleep(3000);
            await this.affiliationRegister.continue();
            await this.driver.sleep(3000);
            await this.contact.continue();
            await this.driver.sleep(3000);
            await this.affiliationSumary.continue();
            await this.sumary.printFiles();
            await this.sumary.cadastroPortal(RFC);
            await this.sumary.uploadFiles(merchant.pdfs);
            // await this.sumary.setUser(merchant.user);
            console.log(`uploadfiles`);
            await this.driver.sleep(3000);
            console.log(`sleep`);
            await this.sumary.cerrarShop();
            console.log(`cerrar`);
            await this.sumary.finishShop();
            console.log(`finish`);
            await this.sumary.continue();
            console.log(`continue`);
            return comercial_name;

            // if (index != merchant.sellers.length - 1) {
            //     await this.sumary.clickHeaderButton("accounts");
            // }
        }

    }

    async addSeller(seller, index) {
        await this.account.chooseAccout(seller.accountOrder);
        await this.affiliationChoice.doAffiliationPreRegister(seller.generalInformation);
        await this.driver.sleep(3000);
        await this.affiliationChoice.continue();
        await this.driver.sleep(3000);
        await this.productSelection.defineFees();
        await this.driver.sleep(3000);
        await this.productSelection.addAllProducts(seller.products);
        await this.driver.sleep(3000);
        await this.productSelection.continue();
        let comercial_name = await this.affiliationRegister.doAffiliationRegister(seller, index);
        // await this.affiliationRegister.continue();
        return comercial_name;
    }

    async getOrderNumbers() {
        return await this.order.getOrderNumbers();
    }

    async setDriver(driver) {
        this.driver = driver;
        this.login = new LoginPage(driver);
        this.home = new HomePage(driver);
        this.account = new AccountPage(driver);
        this.affiliationChoice = new AffiliationChoicePage(driver);
        this.productSelection = new ProductSelectionPage(driver);
        this.affiliationRegister = new AffiliationRegisterPage(driver);
        this.contact = new ContactPage(driver);
        this.affiliationSumary = new AffiliationSumaryPage(driver);
        this.sumary = new SumaryPage(driver);
        this.order = new OrderPage(driver);
        this.legalData = new LegalData(driver);
    }
}