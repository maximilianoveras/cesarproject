const { By, until, Key } = require('selenium-webdriver');
const { INTERNAL_COMPUTE_OFFSET_SCRIPT } = require('selenium-webdriver/lib/input');

module.exports.Base = class {
    constructor(driver) {
        this.By = By;
        this.Key = Key;
        this.driver = driver;
        this.continueButton = this.By.xpath(`//span[contains(text(), 'Continuar')]`);
        this.sleep = {
            LOW: 1000,
            MEDIUM: 5000,
            HIGH: 15000
        };

        this.header = {
            seller: this.By.id("Comercio"),
            accounts: this.By.id("Cuentas"),
            orders: this.By.id("Pedidos")
        };
    }

    async getElement(elementLocation, multiplesElements = false) {
        const waitMethod = !multiplesElements ? until.elementLocated : until.elementsLocated;
        return await this.driver.wait(waitMethod(elementLocation));
    }

    async setContent(elementLocation, content, isCombobox = false, clear = false) {

        if (!isCombobox) {
            const input = await this.getElement(elementLocation);

            if (clear) {
                await input.sendKeys(Key.chord(Key.CONTROL, "a"), content);
            }
            else {
                await input.sendKeys(content);
            }
            
        }
        else {
            const combobox = Object.assign({}, elementLocation);
            combobox.value = combobox.value.replace('<COMBOBOX>', '');
            await this.click(combobox, this.sleep.LOW, false, true);
            const option = this.By.xpath(`//div[text()='${content}']`);
            await this.click(option, this.sleep.LOW, false, true);
        }
    }

    async click(elementLocation, timeToWait = 0, multiplesElements = false, force = false) {
        let element = await this.getElement(elementLocation, multiplesElements);
        
        if (!force) {
            await element.click();
        }
        else {
            await this.driver.executeScript("arguments[0].click()", element);
        }

        await this.driver.sleep(timeToWait);
    }

    async continue() {
        await this.click(this.continueButton, this.sleep.LOW, false, true);
    }

    async fillForm(informations, form) {
        const fields = Object.keys(informations);

        for (let index = 0; index < fields.length; index++) {
            const fieldName = fields[index];
            if(fieldName === 'comprovantDocumentFile'){
                let path = process.cwd();
                informations[fieldName] = path+informations[fieldName];
            }
            const isCombobox = form[fieldName].value.includes('<COMBOBOX>');
            // console.log(`${form[fieldName]}, ${informations[fieldName]}, ${isCombobox}`)
            await this.setContent(form[fieldName], informations[fieldName], isCombobox);
        }
    }

    async clickHeaderButton(buttonName) {
        await this.click(this.header[buttonName], this.sleep.MEDIUM);
    }

    async clear(elementLocation) {
        const element = await this.getElement(elementLocation);
        await element.clear();
    }
}