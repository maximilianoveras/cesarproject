const {Base} = require('../base');
const dataFaker = require('../../datafaker/DataFaker.js');

module.exports.AffiliationRegisterPage = class extends Base {
    constructor(driver) {
        super(driver);
        this.form = {
            name: this.By.name('trade_name'),
            shortName: this.By.name('receipt_name'),
            address: this.By.name('commercial_address.street'),
            number: this.By.name('commercial_address.number'),
            referencePoint1: this.By.name('commercial_address_reference_point1'),
            referencePoint2: this.By.name('commercial_address_reference_point2'),
            postalCode: this.By.name('commercial_address.postal_code'),
            neighborhood: this.By.xpath(`//div[text()='Colonia']<COMBOBOX>`),
            comprovantDocumentType: this.By.xpath(`//label[@label='Tipo de documento']<COMBOBOX>`),
            comprovantDocumentFile: this.By.xpath(`//input[@type='file']`),
            telephoneArea: this.By.xpath(`//div[contains(text(), 'Lada')]/preceding::input[1]`),
            telephoneNumber: this.By.xpath(`//label[@label='Número']//input[@type='text']`),
            productDescriptions: this.By.name('category_free_description'),
            openingTime: this.By.xpath(`//div[contains(text(), 'Abre a las')]/preceding::input[1]`),
            closingTime: this.By.xpath(`//div[contains(text(), 'Cierra a las')]/preceding::input[1]`),
            webSite: this.By.name('web_page')
        };
    }

    async doAffiliationRegister(affiliationInfos, index) {
        // const telephoneAreaInput = await this.getElement(this.form.telephoneArea);
        // await this.driver.executeScript('arguments[0].removeAttribute("disabled");', telephoneAreaInput);
        const affiliationInfosEsp = affiliationInfos.especificInformation
        affiliationInfosEsp.name = `RESTAURANTE ${dataFaker.integer({min: 100000, max: 999999})}`;
        await this.fillForm(affiliationInfosEsp, this.form);
        console.log(affiliationInfosEsp.name);
        return affiliationInfosEsp.name;
        // await this.driver.executeScript("window.scrollTo(600,0)");
        // await this.setContent(this.form.comprovantDocumentType, affiliationInfosEsp.comprovantDocumentType, true);
    }
}