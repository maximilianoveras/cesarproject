const {Base} = require('../base');

module.exports.AffiliationSumaryPage = class extends Base {
    constructor(driver) {
        super(driver);
    }
}