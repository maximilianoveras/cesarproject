const {Base} = require('../base');

module.exports.ContactPage = class extends Base {
    constructor(driver) {
        super(driver);
    }
}