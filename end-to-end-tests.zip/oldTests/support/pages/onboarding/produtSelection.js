const {Base} = require('../base');

module.exports.ProductSelectionPage = class extends Base {
    constructor(driver) {
        super(driver);
        this.confirmFeesButtuon = this.By.xpath(`//div[@name="closed"]`);
        this.genericProductButton = this.By.xpath(`//h2[text() = '<productName>']/../../../..//p[contains(text(), 'AÑADIR AL CARRITO')]`);
    }

    async defineFees() {
        // await this.driver.sleep(100000);
        await this.click(this.confirmFeesButtuon);
    }

    async addProduct(product) {
        for (let index = 0; index < product.quantity; index++) {
            const productButton = Object.assign({}, this.genericProductButton);
            productButton.value = productButton.value.replace('<productName>', product.name);
            await this.click(productButton, this.sleep.LOW);
        }
        
    }

    async addAllProducts(products) {
        await this.driver.sleep(this.sleep.MEDIUM);

        for (let index = 0; index < products.length; index++) {
            const product = products[index];
            await this.addProduct(product);
        }
    }
}