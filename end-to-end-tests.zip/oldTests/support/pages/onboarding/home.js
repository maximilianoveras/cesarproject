const { Base } = require('../base');

module.exports.HomePage = class extends Base {
    constructor(driver) {
        super(driver);
        this.legalDataIsOk = false;
        this.comprovants = {
            RFC: this.By.xpath(`(//a[@class='attach-icon' and contains(text(), 'Adjuntar')])[<index>]`),
            legalDocument: this.By.xpath(`(//a[@class='attach-icon' and contains(text(), 'Adjuntar')])[<index>]`),
            identification: this.By.xpath(`(//a[@class='attach-icon' and contains(text(), 'Adjuntar')])[<index>]`)
        };

        this.legalRepresentativeEditButton = this.By.xpath(`//span[contains(text(), 'Editar')]`);
        this.legalDataBucLabel = this.By.xpath(`//dt[contains(text(), 'Código del Cliente/BUC')]/following::dd[1]`);  

        //Upload Files Modal
        this.documentTypeCombobox = this.By.xpath(`//label[@label='Tipo de documento']`);
        this.inputFile = this.By.xpath(`//input[@type='file']`);
        this.saveFileUploadButton = this.By.xpath(`//span[text()='Guardar']`);
        this.cerrarButton = this.By.xpath(`//span[text()='Cerrar']`)
    }

    async verifyLegalData() {
        const legalDataBuc = await this.getElement(this.legalDataBucLabel);
        const text = await legalDataBuc.getText();
        this.legalDataIsOk = text != "";
    }

    async addComprovants(comprovants) {

        console.log(comprovants)
        
        for (let index = 0; index < comprovants.length; index++) {
            const comprovant = comprovants[index];
            let combobox = Object.assign(this.comprovants[comprovant.name], {});
            combobox.value = combobox.value.replace('<index>', index + 1);
            await this.click(this.By.xpath(`(//a[@class='attach-icon' and contains(text(), 'Adjuntar')])`), this.sleep.LOW, false, true);
            await this.click(this.documentTypeCombobox, this.sleep.LOW);
            const option = this.By.xpath(`//div[text()='${comprovant.type}']`);
            await this.click(option);
            let path = process.cwd();
            await this.setContent(this.inputFile, path+comprovant.path);
            await this.click(this.saveFileUploadButton, 3000, false, true);
            await this.click(this.cerrarButton, 3000, false, true);
        }
        
    }

}