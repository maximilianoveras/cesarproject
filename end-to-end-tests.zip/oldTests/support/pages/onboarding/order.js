const {Base} = require('../base');

module.exports.OrderPage = class extends Base {
    constructor(driver) {
        super(driver);
    }

    async getOrderNumbers() {
        let orderNumbers = [];

        const orderNumbersQuery = this.By.xpath("//h4[contains(text(), 'Pedido N°')]");
        const orderElments = await this.getElement(orderNumbersQuery, true);

        for (let index = 0; index < orderElments.length; index++) {
            const element = orderElments[index];
            const text = await element.getText();
            orderNumbers.push(text.replace('Pedido N° ', ''));
        }

        return orderNumbers;
    }
}