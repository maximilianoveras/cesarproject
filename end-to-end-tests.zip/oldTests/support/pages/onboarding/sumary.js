const {Base} = require('../base');
const fs = require('fs');

module.exports.SumaryPage = class extends Base {
    constructor(driver) {
        super(driver);

        this.printBesp = this.By.xpath(`//span[contains(text(), 'Imprimir Besp')]`);
        this.printCaratula = this.By.xpath(`//span[contains(text(), 'Imprimir Caratula')]`);
        this.registrarPortal = this.By.xpath(`//span[contains(text(), 'Registra tu usuario para acceso al Portal')]`);
        this.uploadAdjuntar = this.By.xpath(`//span[contains(text(), 'Adjuntar')]`);
        this.finish = this.By.xpath(`//span[contains(text(), 'Finalizar Compra')]`);
        this.userButton = this.By.xpath(`//span[contains(text(), 'Registra tu usuario para acceso al Portal')]`);
        this.saveFileUploadButton = this.By.xpath(`//span[text()='Guardar']`);
        this.cerrar = this.By.xpath(`//span[contains(text(), 'Cerrar')]`);
        this.continuar = this.By.xpath(`//span[contains(text(), 'Continuar')]`);

        this.form = {
            name: this.By.name("name"),
            surname: this.By.name("surname"),
            displayName: this.By.name("displayName"),
            email: this.By.xpath(`//div[contains(text(), 'Correo electrónico')]/preceding::input[1]`),
            areaCode: this.By.xpath(`//div[contains(text(), 'LADA')]/preceding::input[1]`),
            phone: this.By.xpath(`//div[contains(text(), 'Número')]/preceding::input[1]`)
        }
    }

    async printFiles() {
        await this.click(this.printBesp, this.sleep.MEDIUM, false, true);
        await this.click(this.printCaratula, this.sleep.MEDIUM, false, true);
    }

    async uploadFiles(pdfs){
        await this.click(this.uploadAdjuntar, this.sleep.MEDIUM, false, true);
        for (let index = 0; index < pdfs.length; index++){
            this.inputFile = this.By.xpath(`//label[@label='Documento ${pdfs[index].name}']//input[@type='file']`);
            let path = process.cwd();
            await this.setContent(this.inputFile, path+pdfs[index].path);
        }
        await this.click(this.saveFileUploadButton, 3000, false, true);
    }

    async cadastroPortal(RFC){
        let RFClower = `${RFC}`.toLowerCase();
        let userInformations = {
            name: 'testeName',
            surname: 'testeSurName',
            displayName: 'testeDisplay',
            email: `${RFClower}@usweek.net`.toLowerCase(),
            areaCode: '51',
            phone: '99999999'
        }
        await this.click(this.registrarPortal, this.sleep.MEDIUM, false, true);
        await this.fillForm(userInformations, this.form);
        await this.click(this.continuar, 3000, false, true);
    }

    async finishShop() {
        await this.click(this.finish, this.sleep.LOW, false, true);
    }

    async cerrarShop() {
        await this.click(this.cerrar, this.sleep.LOW, false, true);
    }

    async setUser(userInformations) {
        const userIsCreated = await this.getElement(this.userButton, true).length > 0;

        // if (userIsCreated) {
            await this.click(this.userButton);
            await this.fillForm(userInformations, this.form);
            //this.continue();
        // }
    }
}