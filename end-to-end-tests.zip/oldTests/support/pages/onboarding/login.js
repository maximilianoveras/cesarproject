const {Base} = require('../base');

module.exports.LoginPage = class extends Base {
    constructor(driver) {
        super(driver);
        this.clientNumberLabel = this.By.xpath(`//span[contains(text(), 'RFC')]`);
        this.clientNumberInput = this.By.name('client_number');
    }

    async doLoginByBUC(clientNumber) {
        await this.click(this.clientNumberLabel);
        await this.setContent(this.clientNumberInput, clientNumber);
        await this.click(this.continueButton);
    }

}