const {Base} = require('../base');
const { Key } = require('selenium-webdriver');

module.exports.LegalData = class extends Base {
    constructor(driver) {
        super(driver);
        this.form = {
            BUC:  this.By.xpath(`//div[contains(text(), 'Número de cliente')]/preceding::input[1]`),
            email:  this.By.xpath(`//div[contains(text(), 'Correo electrónico')]/preceding::input[1]`),
            identificator:  this.By.xpath(`//div[contains(text(), 'Número de identificación')]/preceding::input[1]`)     
        };
    }

    async setLegalData(additionalInfos) {
        await this.driver.sleep(this.sleep.MEDIUM);
        await this.setContent(this.form.BUC, additionalInfos.BUC, false, true);
        await this.setContent(this.form.BUC, Key.TAB);
        await this.driver.sleep(this.sleep.MEDIUM);
        await this.setContent(this.form.email, additionalInfos.email, false, true);
        await this.setContent(this.form.identificator, additionalInfos.identificator, false, true);
    }
}