const {Base} = require('../base');

module.exports.AccountPage = class extends Base {
    constructor(driver) {
        super(driver);
    }

    async chooseAccout(number = 1) {
        this.click(this.By.xpath(`(//div[@name='shop'])[${number}]`));
    }
}