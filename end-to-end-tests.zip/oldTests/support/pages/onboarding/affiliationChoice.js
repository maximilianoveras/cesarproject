const {Base} = require('../base');

module.exports.AffiliationChoicePage = class extends Base {
    constructor(driver) {
        super(driver);
        this.newAffilationOption = this.By.xpath(`//div[contains(text(), 'Nueva Afiliación')]`);

        //Form
        this.form = {
            totalMonthlyRevenue: this.By.xpath(`//div[contains(text(), 'Facturación mensual total')]/preceding::input[1]`),
            transacionalMonthlyRevenue: this.By.xpath(`//div[contains(text(), 'Facturación mensual con tarjetas')]/preceding::input[1]`),
            averageTicket: this.By.xpath(`//div[contains(text(), 'Voucher promedio')]/preceding::input[1]`),
            family: this.By.xpath(`//div[text()='Família']<COMBOBOX>`),
            MCC: this.By.xpath(`//div[text()='GIRO']<COMBOBOX>`)
        };
        
    }

    async doAffiliationPreRegister(generalInformation) {
        await this.click(this.newAffilationOption);
        await this.fillForm(generalInformation, this.form);
    }

}