const DatafakerMerchant = require('../../datafaker/onboarding/datafakerMerchant');
const { envs } = require('../../../env/envs');
const { doRequest, methods } = require('../../request/request');
const Utils = require('../../Utils');

class Operations {

  constructor() { }

  async getMerchantReview(merchant) {
    const fakerMerchant = DatafakerMerchant.generateMerchant(merchant.acquirerMerchantCategoryCode, merchant.categoryCode, merchant.personType);
    const fakerMerchantLegal = DatafakerMerchant.generateMerchantLegal();
    this.baseUrl = envs.ONBOARDING.BACK.QA("merchants");
    await this.updateToken();

    let dataMerchant = await doRequest(`${this.baseUrl}/v1/merchants`, methods.POST, { headers: this.headers, json: fakerMerchant });

    this.merchant_id = dataMerchant.merchant_id;

    await doRequest(`${this.baseUrl}/${this.merchant_id}/qualification`, methods.POST, { headers: this.headers });
    await doRequest(`${this.baseUrl}/${this.merchant_id}/mx-legals`, methods.POST, { headers: this.headers, json: fakerMerchantLegal });
    await doRequest(`${this.baseUrl}/${this.merchant_id}/qualification`, methods.POST, { headers: this.headers });

    dataMerchant = await doRequest(`${this.baseUrl}/${this.merchant_id}`, methods.GET, { headers: this.headers });

    this.registeredMerchant = dataMerchant;
    return dataMerchant;
  };

  async createMerchantAccountActive() {

    const fakerAccount = DatafakerMerchant.generateMerchantAccount(this.merchant_id);
    let dataMerchantAccount = await doRequest(`${this.baseUrl}/accounts/v1/merchant-accounts`, methods.POST, { json: fakerAccount, headers: this.headers });

    this.merchant_account_id = dataMerchantAccount.merchant_account_id;
    await doRequest(`${this.baseUrl}/accounts/v1/merchant-accounts/${this.merchant_account_id}/qualification`, methods.POST, { headers: this.headers });
    dataMerchantAccount = await doRequest(`${this.baseUrl}/accounts/v1/merchant-accounts/${this.merchant_account_id}`, methods.GET, { headers: this.headers });
    return dataMerchantAccount;
  };

  async getMerchantById() {
    let merchant = await doRequest(`${this.baseUrl}/v1/merchants/${this.merchant_id}`, methods.GET, { headers: this.headers });
    merchant = JSON.parse(merchant);
    return merchant;
  };

  async getMerchantAccountById() {
    return await doRequest(`${this.baseUrl}/accounts/v1/merchant-accounts/${this.merchant_account_id}`, methods.GET, { headers: this.headers });
  };

  async generateFulfillment(order) {

    await this.updateToken();

    let affiliation = JSON.parse(await doRequest(`https://api.pre.globalgetnet.com/internal/onboarding/prosa/v1/affiliations/${order.seller_id}`, methods.GET, { headers: this.headers }));
    delete affiliation.seller_id;
    delete affiliation.situation;
    affiliation.affiliation_seller_code = Utils.makeString(7, true);

    console.log("affiliation", affiliation)

    await doRequest(`https://api.pre.globalgetnet.com/internal/onboarding/prosa/v1/affiliations/${order.seller_id}`, methods.PUT, { json: affiliation, headers: this.headers });
    const approvedSituation = {
      "situation": {
        "status": "approved"
      }
    };
    await doRequest(`https://api.pre.globalgetnet.com/internal/onboarding/purchases/v1/orders/${order.order_id}/status`, methods.PATCH, { json: approvedSituation, headers: this.headers });
    
  };

  async approveSeller(seller) {
    await this.updateToken();
    const approvedSituation = {
      "situation": {
        "status": "approved"
      }
    };
    
    await doRequest(`https://api.pre.globalgetnet.com/internal/onboarding/v1/sellers/${seller.seller_id}/status`, methods.PATCH, { json: approvedSituation, headers: this.headers });
  }

  async getFulfillment(order) {

    const getReturn = await doRequest(` https://api.pre.globalgetnet.com/onboarding/purchases/v1/fulfillments?order_id=${order.order_id}`, methods.GET, { headers: this.headers });
    const fulfillment = JSON.parse(getReturn).fulfillments[0];
    console.log("fulfillment",getReturn);

    return fulfillment;
  }

  async getOrdersByMerchantId() {
    this.updateToken();
    const merchantOrders = await doRequest(`https://api.pre.globalgetnet.com/onboarding/purchases/v1/orders?merchant_id=${this.merchant_id}`, methods.GET, { headers: this.headers });
    const orders = JSON.parse(merchantOrders).orders;
    return orders;
  }

  async getSellersByMerchantId() {
    this.updateToken();
    const merchantSellers = await doRequest(`https://api.pre.globalgetnet.com/onboarding/v1/sellers?merchant_id=${this.merchant_id}`, methods.GET, { headers: this.headers });
    const sellers = JSON.parse(merchantSellers).sellers;
    return sellers;
  }

  async updateToken() {
    const token = await Utils.getToken();
    this.headers = {
      "Authorization": `Bearer ${token}`,
      "Accept": "*/*",
      "X-Subscription-Key": "a94ae7388155422889577ab4d630e7f8",
      "scope": "2020"
    };
  }


};

module.exports = Operations;