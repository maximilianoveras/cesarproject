const { createContainer, asClass, asFunction, asValue, InjectionMode, Lifetime } = require('awilix');
const config = require('../config');
const Application = require('./app/Application');
const Server = require('./interfaces/tls/Server');
const logger = require('./infra/logging/logger');
const container = createContainer();

//Integration
const ISOConfigClient = require('./infra/integration/rest/ISOConfigClient');
const TerminalConfigClient = require('./infra/integration/rest/TerminalConfigClient');

//Aplication Insights
const AppInsights = require('applicationinsights');

// System
container
    .register({
        app: asClass(Application).singleton(),
        server: asClass(Server).singleton(),
        logger: asFunction(logger).singleton(),
        container: asValue(container),
        config: asValue(config),
        appInsights: asValue(AppInsights),
        eventHubConfig: asValue(config.integration.amqp.eventHub.pub),
        infoConfig: asValue(config.info),
        amqpPubConfig: asValue(config.integration.amqp.serviceBus.topics.pub),
        serviceBusConnection: asValue(require('@albatross/service-bus')),
        // Integration
        isoConfigClient: asClass(ISOConfigClient).singleton(),
        terminalConfigClient: asClass(TerminalConfigClient).singleton()
    })
    .loadModules([
        'src/app/operations/**/*.js',
        'src/app/services/**/*.js',
        'src/domain/services/**/*.js',
        'src/domain/entities/**/*.js',
        'src/infra/integration/**/*.js',
        [
            'src/infra/integration/serviceBus/ServiceBusProvider.js',
            {
                lifetime: Lifetime.SINGLETON
            }
        ],
        [
            'src/infra/cache/memory/MemoryCache.js',
            {
                lifetime: Lifetime.SINGLETON
            }
        ],
        [
            'src/infra/integration/amqp/MessageBrokerConnection.js',
            {
                lifetime: Lifetime.SINGLETON
            }
        ],
        'src/interfaces/tls/logger/**/*.js',
        'src/interfaces/tls/socket/**/*.js',
        'src/interfaces/tls/routes/**/*.js',
    ],
    {
        formatName: 'camelCase',
        resolverOptions: {
            injectionMode: InjectionMode.PROXY
        }
    });

module.exports = container;
