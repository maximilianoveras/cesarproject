# ISO8583 Library - POC
A implementation to parse JSON X ISO8583-93 message.

## Requirements
NodeJs v8+

## Parser

<pre>
                      +----------------+
                      |                | <--JSON 8583-->
JSON|ISO8583 msg <--- |  ISO8583 LIB   | <--ISO 8583--->
                      |                | <--ISO HEX--->
                      +----------------+
</pre>
                          
## Basic Usage

    // options is optional
    // you can specify:
    // packager(string): default is getnet (available in this moment)
    // staticHeader(string): Any string you can put in HEADER before MTI, max 3 characters
    // lengthHeader(boolean): if true puts the size of message in HEADER
    const packet = new Iso8583Packet(options);
    
    // data must be a string, buffer or json message (see test/index.js to samples).
	packet.process(data);
    
    // the iso8583 Buffer message
	const rawMessage = packet.getRawMessage();

    // new packet parser to receive message
	const parsedPacket = new Iso8583Packet(options);

    // process received message
	parsedPacket.process(rawMessage);

## Test
node test/index.js

