const HttpConnection = require('@albatross/rest-connection');
const httpConnection = new HttpConnection({
    timeout: 100000,
    rejectUnauthorized: false
});

function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
}

async function getAuthCode() {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    const queryParams = {
        'grant_type': 'client_credentials',
        'client_id': 'payments-id',
        'client_secret': 'payments-secret',
        'scope': 'token'
    }
    const response = await httpConnection.post({
        url: 'https://api.pre.globalgetnet.com/oauth2/uat-core/access_token',
        queryParams,
        headers
    })
    return response.data;
}

async function expirationDateToken(seller_code) {
    const accessTokenUAT = await getAuthCode();

    let headers = {
        'X-Subscription-Key': 'a94ae7388155422889577ab4d630e7f8',
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }

    const response = await httpConnection.post({
        headers: headers,
        url: `https://api.pre.globalgetnet.com/internal/payment-channels/v1/tokens/seller/${seller_code}`,
        body: {}
    });
    console.log(JSON.stringify(response.data))
    return response.data;
}

async function activation(token) {
    const accessTokenUAT = await getAuthCode();

    let headers = {
        'X-Subscription-Key': 'a94ae7388155422889577ab4d630e7f8',
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }
    let serial_number = getRandomInt(9999999999999999999).toString()
    const body = {
        application_version: 'MOVE2500.1.10.7',
        serial_number: serial_number,
        token: token
    };

    console.log(body.serial_number);

    const response = await httpConnection.post({
        headers: headers,
        url: 'https://api.pre.globalgetnet.com/internal/payment-channels/v1/activations',
        body
    });
    console.log(response.data);
    return response.data.terminal_code;
}

async function confirmActivation(terminal_code) {
    const accessTokenUAT = await getAuthCode();
    let headers = {
        'X-Subscription-Key': 'a94ae7388155422889577ab4d630e7f8',
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }
    const body = {
        "status": "activated",
        "message": "OK"
    }
    const response = await httpConnection.post({
        headers: headers,
        url: `https://api.pre.globalgetnet.com/payment-channels/v1/activations/${terminal_code}/status`,
        body,
    });
    console.log(response.data);
    return response.data;
}

async function activateTerminal(seller_code, token) {
    await expirationDateToken(seller_code);
    let terminal_code = await activation(token);
    await confirmActivation(terminal_code);
}

activateTerminal('QMKD6141149A74', '08141600504825');

// module.exports = { expirationDateToken, activation };