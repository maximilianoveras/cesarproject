const HttpConnection = require('@albatross/rest-connection');
const httpConnection = new HttpConnection({
    timeout: 1000000,
    rejectUnauthorized: false
});
const dataFaker = require('./DataFaker');

async function getAuthCode() {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    const queryParams = {
        'grant_type': 'client_credentials',
        'client_id': 'payments-id',
        'client_secret': 'payments-secret',
        'scope': 'token'
    }
    const response = await httpConnection.post({
        url: 'https://api.pre.globalgetnet.com/oauth2/uat-core/access_token',
        queryParams,
        headers
    })
    return response.data;
}

async function createMerchant() {
    const accessTokenUAT = await getAuthCode();
    let headers = {
        'X-Subscription-Key': 'a94ae7388155422889577ab4d630e7f8',
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }

    let legal_document_number = `${await dataFaker.makeLegalDocument()}`;

    let body = {
        "country": "MX",
        "external_merchant_id": String(Date.now()).substring(5, 13),
        "legal_document_number": legal_document_number,
        "name": `Comercio UAT - 1612365742714`
    };

    const response = await httpConnection.post({
        url: 'https://api.pre.globalgetnet.com/onboarding/v1/merchants',
        headers,
        body
    });
    return response.data;
};

async function createMerchantLegal(merchant) {
    let RFC = merchant.legal_document_number;
    let merchantID = merchant.merchant_id;
    let email = `${RFC}@usweek.net`.toLowerCase();
    const accessTokenUAT = await getAuthCode();
    let headers = {
        'X-Subscription-Key': 'a94ae7388155422889577ab4d630e7f8',
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }

    let legal_document_number = await dataFaker.generateValidRFC()

    let body = {
        "contacts": [{
            "contact_id": dataFaker.chance.guid({ version: 4 }),
            "external_contact_id": dataFaker.chance.guid({ version: 4 }),
            "identifier_document_number": "string",
            "legal_document_number": legal_document_number,
            "name": "Jose",
            "surname": "Alvaquez",
            "birth_date": "1981-12-10",
            "phone": {
                "country_code": "52",
                "area_code": "55",
                "number": "16576186"
            },
            "cell_phone": {
                "country_code": "52",
                "area_code": "55",
                "number": "16576186"
            },
            "email": email,
            "role": "legal_representative",
            "address": {
                "street": "Calle Parque Lira",
                "number": "SN",
                "suite": "1",
                "district": "Bosque de Chapultepec I Sección",
                "city": "Miguel Hidalgo",
                "state": "TAMPICO",
                "country": "MX",
                "postal_code": "11850"
            },
            "address_reference_point": "string"
        }],
        "fiscal_address": {
            "street": "Calle Parque Lira",
            "number": "SN",
            "suite": "1",
            "district": "Bosque de Chapultepec I Sección",
            "city": "Miguel Hidalgo",
            "state": "TAMPICO",
            "country": "MX",
            "postal_code": "11850"
        },
        "fiscal_address_reference_point1": "Farmacia merchant",
        "fiscal_address_reference_point2": "Restaurante merchant",
        "phone": {
            "country_code": "52",
            "area_code": "55",
            "number": "16576186"
        },
        "commercial_information": {
            "currency": "MXN",
            "gross_monthly_income": 200000,
            "gross_monthly_digital_payments": 200000,
            "average_ticket": 1000
        },
        "days_to_delivery": 0,
        "installments_without_interest": false
    };

    const response = await httpConnection.post({
        url: `https://api.pre.globalgetnet.com/onboarding/v1/merchants/${merchantID}/mx-legals`,
        headers,
        body
    });
};

async function acceptMerchant(merchantID) {
    const accessTokenUAT = await getAuthCode();
    let headers = {
        'X-Subscription-Key': 'a94ae7388155422889577ab4d630e7f8',
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }

    let body = {
        "situation": {
            "status": "accepted"
        }
    }

    const response = await httpConnection.patch({
        url: `https://api.pre.globalgetnet.com/internal/onboarding/v1/merchants/${merchantID}/status`,
        headers,
        body
    });

    return response.data.merchant_id;
};

async function reviewMerchant(merchantID) {
    const accessTokenUAT = await getAuthCode();
    let headers = {
        'X-Subscription-Key': 'a94ae7388155422889577ab4d630e7f8',
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }

    let body = {
        "situation": {
            "status": "review"
        }
    }

    const response = await httpConnection.patch({
        url: `https://api.pre.globalgetnet.com/internal/onboarding/v1/merchants/${merchantID}/status`,
        headers,
        body
    });

    return response.data.merchant_id;
};

async function createMerchantAccount(merchantID) {
    const accessTokenUAT = await getAuthCode();
    let headers = {
        'X-Subscription-Key': 'a94ae7388155422889577ab4d630e7f8',
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }

    let body = {
        "name": "test",
        "account_type": "simple",
        "tags": [
            "string"
        ],
        "bank_account": {
            "bank_code": `${dataFaker.chance.string({ length: 5, numeric: true })}-${dataFaker.chance.string({ length: 1, numeric: true })}`,
            "bank_country": "MX",
            "currency": "MXN",
            "account_number": `${dataFaker.chance.string({ length: 18, numeric: true })}`,
            "branch_code": "BAD336"
        },
        "merchant_id": merchantID
    }

    const response = await httpConnection.post({
        url: `https://api.pre.globalgetnet.com/onboarding/accounts/v1/merchant-accounts`,
        headers,
        body
    });
    return response.data.merchant_account_id;
};

async function getSeller_id(merchant_id) {

    const accessTokenUAT = await getAuthCode();
    let headers = {
        'X-Subscription-Key': 'a94ae7388155422889577ab4d630e7f8',
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }

    let queryParams = {
        "merchant_id": merchant_id,
    }

    const response = await httpConnection.get({
        url: `https://api.pre.globalgetnet.com/onboarding/v1/sellers`,
        headers,
        queryParams
    });
    return response.data.sellers[0].seller_id;
};

async function getMerchant(seller_id) {

    const accessTokenUAT = await getAuthCode();
    let headers = {
        'X-Subscription-Key': 'a94ae7388155422889577ab4d630e7f8',
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }

    const response = await httpConnection.get({
        url: `https://api.pre.globalgetnet.com/onboarding/v1/sellers/${seller_id}`,
        headers
    });
    

    const affiliation_seller_code = String(Date.now()).substring(5, 13).substring(0, 7);
    const data = {
        affiliation_seller_code: affiliation_seller_code,
        seller_code: response.data.seller_code
    }
    return data;
};

async function prosaResponse(data) {

    const accessTokenUAT = await getAuthCode();
    let headers = {
        'X-Subscription-Key': 'a94ae7388155422889577ab4d630e7f8',
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }

    let body = {
        "seller_id": `${data.seller_code}`,
        "affiliation_id": parseInt(data.affiliation_seller_code),
        "prosa_response_status": "A"
    }

    const response = await httpConnection.post({
        url: `https://api.pre.globalgetnet.com/onboarding/affiliations-adp/v1/affiliations-adapter/prosa-data`,
        headers,
        body
    });

    console.log(response.data)
    return response.data.seller_code;
};

async function merchantCreation() {
    const merchant = await createMerchant();
    let legal_document_number = merchant.legal_document_number;
    let merchantID = merchant.merchant_id;
    merchant_id = merchantID;
    await createMerchantLegal(merchant);
    await acceptMerchant(merchantID);
    await reviewMerchant(merchantID);
    merchant_account_id = await createMerchantAccount(merchantID);
    let data = {
        merchant_id: merchantID,
        RFC: legal_document_number
    };
    return data;
}

async function fulfillmentGeneration(merchant_id) {
    let seller_id = await getSeller_id(merchant_id);
    let data = await getMerchant(seller_id);
    let seller_code = await prosaResponse(data);
    return seller_code;
}

// async function teste() {
//     // await merchantCreation();
//     await fulfillmentGeneration('f3cd9fbb-7b2c-4069-be55-0a0666a88475');
// }

// teste()

module.exports = { merchantCreation, fulfillmentGeneration };
