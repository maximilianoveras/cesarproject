const Chance = require('chance');
const chance = new Chance();

async function makeString(length = 18, onlyNumbers = false) {
    let result = '';
    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let numbers = '0123456789';
    for (let i = 0; i < length; i++) {
        if (onlyNumbers) result += numbers.charAt(~~(Math.random() * numbers.length));
        else result += characters.charAt(~~(Math.random() * characters.length));
    }
    return result.toUpperCase();
}

async function makeLegalDocument() {
    const numbers = '0123456789';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let threeOrFour = ~~(Math.random() * (5 - 3)) + 3;
    threeOrFour = 4;
    let res = '';
    for (let i = 0; i < (threeOrFour + 9); i++) {
        if (i < threeOrFour) res += chars.charAt(~~(Math.random() * chars.length));
        else if (i < (threeOrFour + 6)) res += numbers.charAt(~~(Math.random() * numbers.length));
        else res += `${chars}${numbers}`.charAt(~~(Math.random() * `${chars}${numbers}`.length));
    }
    return res;
}

async function randomDate(start, end) {
    const date = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
    let result = `${date.getFullYear().toString().substr(-2)}${date.getMonth(date)}${date.getDay(date)}`;
    return result.toUpperCase();
}

async function generateValidRFC (year = 1960) {
    return `${await makeString(~~(Math.random() * (5 - 3)) + 3)}${await randomDate(new Date(year, 0, 1), new Date(2001, 0, 1))}${await makeString(3)}`;
}

module.exports = {chance, generateValidRFC, makeLegalDocument, makeString};
