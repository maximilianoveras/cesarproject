'use strict';
const moment = require('moment')
const dataFaker = require('./DataFaker');
const HttpConnection = require('@albatross/rest-connection');
const httpConnection = new HttpConnection({
    timeout: 1000000,
    rejectUnauthorized: false
});
// const fs = require('fs');
let report = []
const envs = require('./envs');
const { listModules } = require('awilix');
// let reportCheckin = require('report6643152-CHECKIN-20200930-1230.json')
// let reportARR = []
// for (let p = 0; p <= reportCheckin.length - 1; p++) {
//     reportARR.push({
//         payment_id: reportCheckin.map(i => i.CHECKINResponse.payment_id)[p],
//         amount: reportCheckin.map(i => i.CHECKINResponse.amount)[p]
//     })
// }
async function getAuthCode() {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    const queryParams = envs.token[`${process.env.NODE_ENV}`].TOKEN.QUERY
    const response = await httpConnection.post({
        url: envs.token[`${process.env.NODE_ENV}`].TOKEN.URL,
        queryParams,
        headers
    })
    return response.data;
}

async function sendTransactionCP(accessTokenUAT, cardData, type) {
    let headers = {
        'x-seller-code': `${process.env.SELLER_CODE}`,
        'X-Subscription-Key': envs.token[`${process.env.NODE_ENV}`].SUBSCRIPTION_KEY, // UAT
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }
    const amount = dataFaker.chance.integer({ min: 1, max: 1000 });
    let datetime_transaction = new Date().toISOString()
    let newHours = parseInt(datetime_transaction.slice(11, 13)) - 5
    let newMinutes = parseInt(datetime_transaction.slice(14, 16)) - 5
    if (newMinutes < 0) {
        newMinutes = '55'
        newHours = newHours - 1
    }
    newMinutes = newMinutes.toString()
    if (newMinutes.length % 2 !== 0) {
        newMinutes = `0${newMinutes}`
    }
    newHours = newHours.toString()
    if (newHours.length % 2 !== 0) {
        newHours = `0${newHours}`
    }
    let newDate = '2021-01-07T'
    datetime_transaction = datetime_transaction.slice(0, 11) + newHours + ':' + newMinutes + ':' + datetime_transaction.slice(17, 19) + '-05:00'
    // datetime_transaction = newDate + newHours + ':' + newMinutes + ':' + datetime_transaction.slice(17, 19) + '-05:00'
    let body = {
        "amount": amount,
        "datetime_transaction": datetime_transaction,
        "currency": "MXN",
        "system_trace_audit_number": dataFaker.chance.integer({ min: 1, max: 99999 }),
        "terminal": {
            "capabilitys": {
                "input": "ICC_MAGSTRIPE_KEYED_CONTACTLESS",
                "authentication": "PIN",
                "card_capture": false,
                "output": "PRINTING_AND_DISPLAY",
                "pin_capture": 4
            }
        },
        "transaction_channel_type": "pos",
        "card": {
            "card_number": cardData.card_number,
            "entry_mode": "magnetic_stripe",
            "track_2": `${cardData.card_number}d2110201372810229`,
            "smid": "FYJ5CQR0II418KG8AJRX8DCHQ2W3QB2GV6PE4JRK",
            "expiration_month": "12",
            "expiration_year": "21"
        },
        "reference_code": `00000` + dataFaker.chance.string({ length: 6, numeric: true }),
        // "operation": cardData.operation
    };
    if (type === 'QPS') {
        body.special_payment_indicator = "qps";
    } else if (type === 'CHECKIN') {
        body.capture_mode = "manual";
        body.pre_authorization = {
            "authorization_ref_code": dataFaker.chance.string({ numeric: true, length: 6 }),
            "type": "lodging"
        };
    } else if (type === 'RECURRING') {
        body.recurring = {
            "payments_identification": dataFaker.chance.string({ length: 13, numeric: true })
        };
    } else if (type === 'MSI') {
        let installments = parseInt(`${process.env.INSTALLMENTS}`)
        console.log(installments)
        body.installment = {
            "type": "no_interest",
            "number": installments
        };
    } else if (type === 'CNP') {
        body = {
            "amount": amount,
            "datetime_transaction": datetime_transaction,
            "currency": "MXN",
            "system_trace_audit_number": dataFaker.chance.integer({ min: 1, max: 99999 }),
            "transaction_channel_type": "recurring",
            "card": {
                "entry_mode": "recurring_payment",
                "card_number": cardData.card_number,
                "expiration_month": "12",
                "expiration_year": "21"
            },
            "reference_code": `00000` + dataFaker.chance.string({ length: 6, numeric: true }),
            // "operation": cardData.operation,
            "recurring": {
                "payments_identification": dataFaker.chance.string({ length: 13, alpha: true })
            }
        };
    }
    let fakeBody = {
        payment_id: null
    }
    let url = envs.urls(fakeBody)
    const response = await httpConnection.post({
        url: url[process.env.NODE_ENV].PRE_AUTHORIZATION,
        body,
        headers
    });
    // console.log(response)
    let transactionReport = {
        [`${type}RequestURL`]: response.config.url,
        [`${type}Request`]: body,
        [`${type}Response`]: response.data
    }
    report.push(transactionReport);
    // console.log(response)
    return response.data;
}

async function afterTransaction(accessTokenUAT, paymentParams, type) {
    let headers = {
        'x-seller-code': `${process.env.SELLER_CODE}`,
        'X-Subscription-Key': envs.token[`${process.env.NODE_ENV}`].SUBSCRIPTION_KEY,
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }
    let url = envs.urls(paymentParams)
    const response = await httpConnection.post({
        url: url[`${process.env.NODE_ENV}`][`${type}`],
        headers
    });
    let afterReport = {
        [`${type}RequestURL`]: response.config.url,
        [`${type}Response`]: response.data
    }
    report.push(afterReport);
    return response.data;
}

async function captureTransaction(accessTokenUAT, paymentParams) {
    let headers = {
        'x-seller-code': `${process.env.SELLER_CODE}`,
        'X-Subscription-Key': envs.token[`${process.env.NODE_ENV}`].SUBSCRIPTION_KEY,
        'Authorization': `Bearer ${accessTokenUAT.access_token}`,
    }
    const body = {
        "amount": paymentParams.amount,
        "card": paymentParams.card
    }
    let url = envs.urls(paymentParams)
    const response = await httpConnection.post({
        url: url[`${process.env.NODE_ENV}`].CAPTURE,
        headers,
        body
    });
    let captureReport = {
        'CHECKOUTRequestURL': response.config.url,
        'CHECKOUTRequest': body,
        'CHECKOUTResponse': response.data
    }
    report.push(captureReport);
    return response.data;
}

const getDate = async () => {
    let day = await moment().date().toString()
    if (day.length < 2) {
        day = `0${day}`
    }
    let month = await moment().month()
    month = (month + 1).toString()
    if (month.length < 2) {
        month = '0' + month
    };
    let year = await moment().year().toString()
    let hour = await moment().hour().toString()
    if (hour.length < 2) {
        hour = '0' + hour
    };
    let minute = await moment().minute().toString()
    if (minute.length < 2) {
        minute = '0' + minute
    };
    const dateString = `${year}${month}${day}-${hour}${minute}`
    return dateString;
}

async function testTest() {
    let cardData = [
        // { card_number: '374245001781003', operation: 'credit' }, // AMEX // W
        // { card_number: '374245002741006', operation: 'credit' }, // AMEX // W
        // { card_number: '374245003731006', operation: 'credit' }, // AMEX // W
        // { card_number: '374245001031003', operation: 'credit' }, // AMEX // W
        // { card_number: '373953192351004', operation: 'credit' }, // AMEX // W
        { card_number: '5579083155321546', operation: 'debit' }, // MASTERCARD INTERNATIONAL // W
        { card_number: '4931358000318798', operation: 'credit' }, // VISA INTERNATIONAL // W
        { card_number: '5163661455551334', operation: 'debit' }, // MASTERCARD INTERNATIONAL // W
        { card_number: '5453071876210461', operation: 'credit' }, // MASTERCARD DOMESTIC // W
        { card_number: '5284304018170656', operation: 'debit' }, // MASTERCARD DOMESTIC // W
        { card_number: '4761733001562351', operation: 'credit' }, // VISA INTERNATIONAL // W
        { card_number: '4913443503626269', operation: 'debit' }, // VISA DOMESTIC // W
        { card_number: '4800773304527324', operation: 'credit' }, // VISA DOMESTIC // W
        { card_number: '5064335043004151', operation: 'credit' }, // CARNET DOMESTIC // W
        { card_number: '5062153054222071', operation: 'debit' }, // CARNET DOMESTIC // W
    ];
    if (process.env.CASE === 'MSI') {
        cardData = [
            { card_number: '5413330089750914', operation: 'credit' }, // MASTERCARD INTERNATIONAL // W
            { card_number: '5453071876210461', operation: 'credit' }, // MASTERCARD DOMESTIC // W
            { card_number: '4761733001562351', operation: 'credit' }, // VISA INTERNATIONAL // W
            { card_number: '4800773304527324', operation: 'credit' }, // VISA DOMESTIC // W
            // { card_number: '374245001781003', operation: 'credit' }, // AMEX // W
            // { card_number: '374245002741006', operation: 'credit' }, // AMEX // W
            // { card_number: '374245003731006', operation: 'credit' }, // AMEX // W
            // { card_number: '374245001031003', operation: 'credit' }, // AMEX // W
            // { card_number: '373953192351004', operation: 'credit' } // AMEX // W
        ];
    }
    let type;
    if (process.env.CASE !== 'CHECKOUT') {
        for (let i = 0; i <= cardData.length - 1; i++) {
            console.log(cardData[i].card_number)
            const accessTokenUAT = await getAuthCode();
            let test;
            let testCapture;
            let testCancellation;
            let testRefund;
            test = await sendTransactionCP(accessTokenUAT, cardData[i], `${process.env.CASE}`);
            // type = `${process.env.SELLER_CODE}-${process.env.CASE}-`;
            if (process.env.CASE === 'MSI') {
                type = `${process.env.SELLER_CODE}-${process.env.CASE}-${process.env.INSTALLMENTS}-`;
            } else {
                type = `${process.env.SELLER_CODE}-${process.env.CASE}-`;
            }
            console.log(test)
            if (process.env.AFTER_CASE && process.env.AFTER_CASE === 'CHECKOUT') {
                testCapture = await captureTransaction(accessTokenUAT, test);
                console.log(testCapture)
            } else if (process.env.AFTER_CASE && process.env.AFTER_CASE !== 'CHECKOUT' && process.env.AFTER_CASE !== 'REFUND') {
                testCancellation = await afterTransaction(accessTokenUAT, test, `${process.env.AFTER_CASE}`)
                console.log(testCancellation)
            } else if (process.env.AFTER_CASE && process.env.AFTER_CASE === 'REFUND') {
                testRefund = await afterTransaction(accessTokenUAT, test, `${process.env.AFTER_CASE}`)
                console.log(testRefund)
            }
        }
    }
    if (process.env.CASE === 'CHECKOUT') {
        for (let i = 0; i <= reportARR.length - 1; i++) {
            const accessTokenUAT = await getAuthCode();
            let testCapture = await captureTransaction(accessTokenUAT, reportARR[i]);
            console.log(testCapture)
        };
        type = `${process.env.SELLER_CODE}-CHECKOUT`;
    }
    if (process.env.AFTER_CASE && process.env.AFTER_CASE === 'CHECKOUT') {
        type = type + 'CHECKOUT-';
    } else if (process.env.AFTER_CASE && process.env.AFTER_CASE !== 'CHECKOUT' && process.env.AFTER_CASE !== 'REFUND') {
        type = type + `${process.env.AFTER_CASE}-`;
    } else if (process.env.AFTER_CASE && process.env.AFTER_CASE === 'REFUND') {
        type = type + `${process.env.AFTER_CASE}-`;
    }
    // const dateString = await getDate();
    // let dir = `${process.env.SELLER_CODE}-${dateString.slice(0, 8)}`
    // if (!fs.existsSync(dir)) {
    //     fs.mkdirSync(dir);
    // }
    // fs.writeFile(`${dir}/report${type}${dateString}.json`, JSON.stringify(report, null, 4), function (err) {
    //     if (err) return console.log(err);
    // });
    // console.log(`Wrote Report file: report${type}${dateString}.json`)
}

// let seller_codes = [
//     // "2727993",
//     // "8256432",
//     // "1837736",
//     // "6643152",
//     "1837736"
// ]
async function kek(seller_code) {
    process.env.SELLER_CODE = seller_code
    process.env.CASE = 'QPS'
    await testTest();
}


module.exports = {kek}
// kek();



