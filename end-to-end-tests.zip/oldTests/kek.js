const {
    Builder,
    Browser,
    Options
} = require('selenium-webdriver');
const chrome = require("selenium-webdriver/chrome");

const getNewDriver = async () => {
    const options = new chrome.Options();
    options.addArguments('--ignore-certificate-errors');
    options.addArguments('--ignore-ssl-errors');
    options.addArguments('--start-maximized');
    options.addArguments('--trusted-download-sources');

    options.setUserPreferences({
        'profile.default_content_setting_values.notifications': 2
    });
    const driver = new Builder()
        .forBrowser(Browser.CHROME)
        .withCapabilities(options)
        .build();

    return driver;
}

const test = async () => {
    let driver = await getNewDriver();
}

test();